import React from 'react';

type BadgeVariant = 'live' | 'upcoming' | 'completed' | 'draft' | 'trending' | 'free' | 'paid' | 'limited' | 'full';

interface StatusBadgeProps {
  variant: BadgeVariant;
  label?: string;
  pulse?: boolean;
  className?: string;
}

const variantConfig: Record<BadgeVariant, { bg: string; text: string; border: string; defaultLabel: string }> = {
  live: { bg: 'bg-success/10', text: 'text-success', border: 'border-success/30', defaultLabel: 'Live Now' },
  upcoming: { bg: 'bg-accent/10', text: 'text-accent', border: 'border-accent/20', defaultLabel: 'Upcoming' },
  completed: { bg: 'bg-muted', text: 'text-muted-foreground', border: 'border-border', defaultLabel: 'Completed' },
  draft: { bg: 'bg-warning/10', text: 'text-warning', border: 'border-warning/20', defaultLabel: 'Draft' },
  trending: { bg: 'bg-primary/10', text: 'text-primary', border: 'border-primary/20', defaultLabel: 'Trending' },
  free: { bg: 'bg-success/10', text: 'text-success', border: 'border-success/20', defaultLabel: 'Free' },
  paid: { bg: 'bg-accent/10', text: 'text-accent', border: 'border-accent/20', defaultLabel: 'Paid' },
  limited: { bg: 'bg-warning/10', text: 'text-warning', border: 'border-warning/20', defaultLabel: 'Limited Seats' },
  full: { bg: 'bg-danger/10', text: 'text-danger', border: 'border-danger/20', defaultLabel: 'Full' },
};

export default function StatusBadge({ variant, label, pulse, className = '' }: StatusBadgeProps) {
  const config = variantConfig[variant];
  return (
    <span
      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-600 border ${config.bg} ${config.text} ${config.border} ${className}`}
    >
      {pulse && (
        <span className={`w-1.5 h-1.5 rounded-full ${variant === 'live' ? 'bg-success live-pulse' : 'bg-current'}`} />
      )}
      {label || config.defaultLabel}
    </span>
  );
}