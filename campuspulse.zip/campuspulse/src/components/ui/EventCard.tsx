'use client';

import React, { useState } from 'react';
import AppImage from '@/components/ui/AppImage';
import Icon from '@/components/ui/AppIcon';
import StatusBadge from '@/components/ui/StatusBadge';
import { toast } from 'sonner';

export interface EventCardData {
  id: string;
  title: string;
  club: string;
  clubLogo: string;
  banner: string;
  bannerAlt: string;
  category: string;
  date: string;
  time: string;
  location: string;
  registrations: number;
  capacity: number;
  status: 'live' | 'upcoming' | 'completed';
  isFree: boolean;
  price?: number;
  isTrending?: boolean;
  isRegistered?: boolean;
  isSaved?: boolean;
  aiMatchScore?: number;
  tags: string[];
}

interface EventCardProps {
  event: EventCardData;
  variant?: 'default' | 'compact' | 'featured';
}

export default function EventCard({ event, variant = 'default' }: EventCardProps) {
  const [saved, setSaved] = useState(event.isSaved || false);
  const [registered, setRegistered] = useState(event.isRegistered || false);
  const [loading, setLoading] = useState(false);

  const capacityPct = Math.round((event.registrations / event.capacity) * 100);
  const isAlmostFull = capacityPct >= 80;

  const handleRegister = async () => {
    if (registered) return;
    setLoading(true);
    // BACKEND: POST /api/events/{event.id}/register
    await new Promise((r) => setTimeout(r, 800));
    setRegistered(true);
    setLoading(false);
    toast.success(`Registered for ${event.title}! Check your QR code in My Events.`);
  };

  const handleSave = () => {
    setSaved(!saved);
    // BACKEND: POST /api/events/{event.id}/save
    toast.success(saved ? 'Removed from saved events' : 'Saved to your events');
  };

  return (
    <div className="event-card rounded-2xl overflow-hidden group">
      {/* Banner */}
      <div className="relative h-44 overflow-hidden">
        <AppImage
          src={event.banner}
          alt={event.bannerAlt}
          fill
          className="object-cover group-hover:scale-105 transition-transform duration-500"
          sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />

        {/* Top badges */}
        <div className="absolute top-3 left-3 flex items-center gap-2">
          {event.status === 'live' && <StatusBadge variant="live" pulse />}
          {event.isTrending && event.status !== 'live' && <StatusBadge variant="trending" />}
          {event.aiMatchScore && (
            <span className="flex items-center gap-1 bg-primary/80 backdrop-blur-sm text-white text-xs font-600 px-2 py-1 rounded-full">
              <Icon name="SparklesIcon" size={10} />
              {event.aiMatchScore}% match
            </span>
          )}
        </div>

        {/* Save button */}
        <button
          onClick={handleSave}
          className="absolute top-3 right-3 p-2 rounded-full bg-black/40 backdrop-blur-sm hover:bg-black/60 transition-all"
          aria-label={saved ? 'Remove from saved' : 'Save event'}
        >
          <Icon
            name="BookmarkIcon"
            size={16}
            variant={saved ? 'solid' : 'outline'}
            className={saved ? 'text-primary' : 'text-white'}
          />
        </button>

        {/* Club logo + name */}
        <div className="absolute bottom-3 left-3 flex items-center gap-2">
          <div className="w-7 h-7 rounded-full bg-primary flex items-center justify-center text-white text-xs font-700 flex-shrink-0">
            {event.club.charAt(0)}
          </div>
          <span className="text-white text-xs font-600 drop-shadow">{event.club}</span>
        </div>

        {/* Free / Paid */}
        <div className="absolute bottom-3 right-3">
          <StatusBadge variant={event.isFree ? 'free' : 'paid'} label={event.isFree ? 'Free' : `₹${event.price}`} />
        </div>
      </div>

      {/* Content */}
      <div className="p-4 space-y-3">
        <div>
          <h3 className="text-sm font-700 text-foreground leading-snug line-clamp-2 group-hover:text-primary transition-colors">
            {event.title}
          </h3>
          <p className="text-xs text-muted-foreground mt-1">{event.category}</p>
        </div>

        {/* Meta */}
        <div className="space-y-1.5">
          <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <Icon name="CalendarIcon" size={12} />
            <span>{event.date} · {event.time}</span>
          </div>
          <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <Icon name="MapPinIcon" size={12} />
            <span className="truncate">{event.location}</span>
          </div>
        </div>

        {/* Capacity bar */}
        <div className="space-y-1">
          <div className="flex items-center justify-between text-xs">
            <span className="text-muted-foreground">{event.registrations} registered</span>
            <span className={`font-600 ${isAlmostFull ? 'text-warning' : 'text-muted-foreground'}`}>
              {event.capacity - event.registrations} left
            </span>
          </div>
          <div className="h-1.5 bg-muted rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full transition-all ${
                capacityPct >= 90 ? 'bg-danger' : isAlmostFull ? 'bg-warning' : 'bg-primary'
              }`}
              style={{ width: `${Math.min(capacityPct, 100)}%` }}
            />
          </div>
        </div>

        {/* Tags */}
        <div className="flex flex-wrap gap-1">
          {event.tags.slice(0, 3).map((tag) => (
            <span key={`tag-${event.id}-${tag}`} className="text-xs bg-muted text-muted-foreground px-2 py-0.5 rounded-full">
              #{tag}
            </span>
          ))}
        </div>

        {/* Action */}
        <button
          onClick={handleRegister}
          disabled={loading || registered || capacityPct >= 100}
          className={`w-full py-2.5 rounded-xl text-sm font-600 transition-all duration-150 flex items-center justify-center gap-2 ${
            registered
              ? 'bg-success/10 text-success border border-success/20 cursor-default'
              : capacityPct >= 100
              ? 'bg-muted text-muted-foreground cursor-not-allowed'
              : 'btn-primary'
          }`}
        >
          {loading ? (
            <>
              <Icon name="ArrowPathIcon" size={14} className="animate-spin" />
              <span>Registering...</span>
            </>
          ) : registered ? (
            <>
              <Icon name="CheckCircleIcon" size={14} />
              <span>Registered</span>
            </>
          ) : capacityPct >= 100 ? (
            'Event Full'
          ) : (
            'Register Now'
          )}
        </button>
      </div>
    </div>
  );
}