'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import AppLogo from '@/components/ui/AppLogo';
import Icon from '@/components/ui/AppIcon';

interface NavItem {
  label: string;
  icon: string;
  href: string;
  badge?: number;
  group?: string;
}

const navItems: NavItem[] = [
  { label: 'Discover', icon: 'HomeIcon', href: '/homepage', group: 'main' },
  { label: 'My Dashboard', icon: 'Squares2X2Icon', href: '/student-dashboard', group: 'main' },
  { label: 'My Events', icon: 'CalendarDaysIcon', href: '/student-dashboard', group: 'main', badge: 3 },
  { label: 'Clubs', icon: 'UserGroupIcon', href: '/homepage', group: 'explore' },
  { label: 'Categories', icon: 'TagIcon', href: '/homepage', group: 'explore' },
  { label: 'Leaderboard', icon: 'TrophyIcon', href: '/student-dashboard', group: 'explore' },
  { label: 'Notifications', icon: 'BellIcon', href: '/student-dashboard', group: 'personal', badge: 5 },
  { label: 'Saved Events', icon: 'BookmarkIcon', href: '/student-dashboard', group: 'personal' },
  { label: 'Profile', icon: 'UserCircleIcon', href: '/student-dashboard', group: 'personal' },
];

const groups = [
  { key: 'main', label: 'Navigation' },
  { key: 'explore', label: 'Explore' },
  { key: 'personal', label: 'Personal' },
];

interface SidebarProps {
  activePath?: string;
}

export default function Sidebar({ activePath }: SidebarProps) {
  const [collapsed, setCollapsed] = useState(false);

  return (
    <>
      {/* Desktop Sidebar */}
      <aside
        className="hidden lg:flex flex-col bg-card border-r border-border transition-all duration-300 ease-in-out flex-shrink-0"
        style={{ width: collapsed ? '64px' : '240px' }}
      >
        {/* Logo */}
        <div className="flex items-center gap-3 px-4 py-5 border-b border-border min-h-[64px]">
          <div className="flex-shrink-0">
            <AppLogo size={32} />
          </div>
          {!collapsed && (
            <span className="font-bold text-lg text-foreground tracking-tight whitespace-nowrap overflow-hidden">
              CampusPulse
            </span>
          )}
        </div>

        {/* Nav Items */}
        <nav className="flex-1 py-4 overflow-y-auto scrollbar-hide">
          {groups.map((group) => {
            const groupItems = navItems.filter((item) => item.group === group.key);
            return (
              <div key={`group-${group.key}`} className="mb-4">
                {!collapsed && (
                  <p className="px-4 py-1 text-xs font-600 tracking-widest text-muted-foreground uppercase mb-1">
                    {group.label}
                  </p>
                )}
                {groupItems.map((item) => {
                  const isActive = activePath === item.href;
                  return (
                    <Link
                      key={`nav-${item.label.toLowerCase().replace(/\s/g, '-')}`}
                      href={item.href}
                      title={collapsed ? item.label : undefined}
                      className={`flex items-center gap-3 px-4 py-2.5 mx-2 rounded-lg transition-all duration-150 group relative ${
                        isActive
                          ? 'nav-item-active' :'text-muted-foreground hover:text-foreground hover:bg-muted'
                      }`}
                    >
                      <div className="flex-shrink-0 relative">
                        <Icon
                          name={item.icon as any}
                          size={18}
                          variant={isActive ? 'solid' : 'outline'}
                          className={isActive ? 'text-primary' : ''}
                        />
                        {item.badge && item.badge > 0 && (
                          <span className="absolute -top-1.5 -right-1.5 bg-primary text-white text-xs rounded-full w-4 h-4 flex items-center justify-center font-600 tabular-nums">
                            {item.badge}
                          </span>
                        )}
                      </div>
                      {!collapsed && (
                        <span className="text-sm font-500 whitespace-nowrap">{item.label}</span>
                      )}
                    </Link>
                  );
                })}
              </div>
            );
          })}
        </nav>

        {/* Bottom: User + Collapse */}
        <div className="border-t border-border p-3 space-y-2">
          {!collapsed && (
            <div className="flex items-center gap-3 px-2 py-2 rounded-lg hover:bg-muted cursor-pointer transition-colors">
              <div className="w-8 h-8 rounded-full gradient-primary flex items-center justify-center text-white text-xs font-700 flex-shrink-0">
                AR
              </div>
              <div className="min-w-0">
                <p className="text-sm font-600 text-foreground truncate">Arjun Reddy</p>
                <p className="text-xs text-muted-foreground truncate">CS • 3rd Year</p>
              </div>
            </div>
          )}
          <button
            onClick={() => setCollapsed(!collapsed)}
            className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted transition-all duration-150"
            aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
          >
            <Icon
              name={collapsed ? 'ChevronRightIcon' : 'ChevronLeftIcon'}
              size={16}
            />
            {!collapsed && <span className="text-xs font-500">Collapse</span>}
          </button>
        </div>
      </aside>

      {/* Mobile Bottom Nav */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-50 bg-card border-t border-border flex items-center justify-around px-2 py-2 safe-area-pb">
        {[
          { label: 'Home', icon: 'HomeIcon', href: '/homepage' },
          { label: 'Events', icon: 'CalendarDaysIcon', href: '/student-dashboard' },
          { label: 'Discover', icon: 'MagnifyingGlassIcon', href: '/homepage' },
          { label: 'Alerts', icon: 'BellIcon', href: '/student-dashboard', badge: 5 },
          { label: 'Me', icon: 'UserCircleIcon', href: '/student-dashboard' },
        ].map((item) => {
          const isActive = activePath === item.href;
          return (
            <Link
              key={`mobile-nav-${item.label.toLowerCase()}`}
              href={item.href}
              className={`flex flex-col items-center gap-1 px-3 py-1 rounded-lg transition-all ${
                isActive ? 'text-primary' : 'text-muted-foreground'
              }`}
            >
              <div className="relative">
                <Icon name={item.icon as any} size={20} variant={isActive ? 'solid' : 'outline'} />
                {item.badge && (
                  <span className="absolute -top-1.5 -right-1.5 bg-primary text-white text-xs rounded-full w-4 h-4 flex items-center justify-center font-600">
                    {item.badge}
                  </span>
                )}
              </div>
              <span className="text-xs font-500">{item.label}</span>
            </Link>
          );
        })}
      </nav>
    </>
  );
}