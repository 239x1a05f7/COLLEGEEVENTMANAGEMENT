'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import Icon from '@/components/ui/AppIcon';

export default function AppTopbar() {
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  return (
    <header className="h-16 bg-card border-b border-border flex items-center justify-between px-4 lg:px-6 flex-shrink-0 z-40">
      {/* Left: Search */}
      <div className="flex items-center gap-3 flex-1 max-w-md">
        {searchOpen ? (
          <div className="flex items-center gap-2 bg-muted rounded-xl px-3 py-2 flex-1 border border-primary/30">
            <Icon name="MagnifyingGlassIcon" size={16} className="text-muted-foreground flex-shrink-0" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e?.target?.value)}
              placeholder="Search events, clubs, categories..."
              className="bg-transparent text-sm text-foreground placeholder-muted-foreground outline-none flex-1"
              autoFocus
            />
            <button onClick={() => { setSearchOpen(false); setSearchQuery(''); }}>
              <Icon name="XMarkIcon" size={14} className="text-muted-foreground hover:text-foreground" />
            </button>
          </div>
        ) : (
          <button
            onClick={() => setSearchOpen(true)}
            className="flex items-center gap-2 bg-muted rounded-xl px-3 py-2 text-muted-foreground hover:text-foreground hover:border-border border border-transparent transition-all text-sm"
          >
            <Icon name="MagnifyingGlassIcon" size={16} />
            <span className="hidden sm:block">Search events...</span>
            <span className="hidden lg:flex items-center gap-1 ml-2 text-xs bg-secondary rounded px-1.5 py-0.5 border border-border">
              <span>⌘K</span>
            </span>
          </button>
        )}
      </div>
      {/* Right: Actions */}
      <div className="flex items-center gap-2">
        {/* Live indicator */}
        <div className="hidden sm:flex items-center gap-1.5 bg-success/10 border border-success/20 rounded-full px-3 py-1.5">
          <span className="w-2 h-2 rounded-full bg-success live-pulse"></span>
          <span className="text-xs font-600 text-success">4 Live Now</span>
        </div>

        {/* Notifications */}
        <Link href="/student-dashboard" className="relative p-2 rounded-xl text-muted-foreground hover:text-foreground hover:bg-muted transition-all">
          <Icon name="BellIcon" size={20} />
          <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-primary rounded-full"></span>
        </Link>

        {/* AI Assistant */}
        <button className="hidden sm:flex items-center gap-2 gradient-primary text-white text-xs font-600 px-3 py-2 rounded-xl hover:opacity-90 transition-all">
          <Icon name="SparklesIcon" size={14} />
          <span>AI Assistant</span>
        </button>

        {/* Avatar */}
        <div className="w-9 h-9 rounded-full gradient-primary flex items-center justify-center text-white text-sm font-700 cursor-pointer hover:opacity-90 transition-all">
          AR
        </div>
      </div>
    </header>
  );
}