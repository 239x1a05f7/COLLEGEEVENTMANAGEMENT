'use client';

import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { useRouter } from 'next/navigation';
import Icon from '@/components/ui/AppIcon';
import { toast } from 'sonner';

interface SignUpFormData {
  fullName: string;
  email: string;
  college: string;
  department: string;
  year: string;
  password: string;
  confirmPassword: string;
  role: 'student' | 'club_admin';
  agreeTerms: boolean;
}

const interestCategories = [
  { id: 'int-tech', label: 'Technology', emoji: '💻' },
  { id: 'int-ai', label: 'AI & ML', emoji: '🤖' },
  { id: 'int-design', label: 'Design', emoji: '🎨' },
  { id: 'int-music', label: 'Music', emoji: '🎵' },
  { id: 'int-sports', label: 'Sports', emoji: '⚽' },
  { id: 'int-dance', label: 'Dance', emoji: '💃' },
  { id: 'int-debate', label: 'Debate', emoji: '🗣️' },
  { id: 'int-photography', label: 'Photography', emoji: '📸' },
  { id: 'int-startup', label: 'Entrepreneurship', emoji: '🚀' },
  { id: 'int-literature', label: 'Literature', emoji: '📚' },
  { id: 'int-film', label: 'Film & Media', emoji: '🎬' },
  { id: 'int-gaming', label: 'Gaming', emoji: '🎮' },
  { id: 'int-science', label: 'Science', emoji: '🔬' },
  { id: 'int-environment', label: 'Environment', emoji: '🌿' },
  { id: 'int-social', label: 'Social Impact', emoji: '🤝' },
  { id: 'int-culinary', label: 'Food & Culinary', emoji: '🍳' },
  { id: 'int-robotics', label: 'Robotics', emoji: '🦾' },
  { id: 'int-wellness', label: 'Wellness', emoji: '🧘' },
];

const departments = ['Computer Science', 'Electronics & Comm.', 'Mechanical', 'Civil', 'Chemical', 'Electrical', 'IT', 'Mathematics', 'Physics', 'Other'];
const years = ['1st Year', '2nd Year', '3rd Year', '4th Year', 'PG 1st Year', 'PG 2nd Year', 'PhD'];

interface SignUpFormProps {
  onSwitchToLogin: () => void;
}

export default function SignUpForm({ onSwitchToLogin }: SignUpFormProps) {
  const router = useRouter();
  const [step, setStep] = useState<1 | 2>(1);
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedInterests, setSelectedInterests] = useState<string[]>([]);

  const {
    register,
    handleSubmit,
    watch,
    trigger,
    formState: { errors },
  } = useForm<SignUpFormData>({
    defaultValues: { role: 'student' },
  });

  const password = watch('password');

  const toggleInterest = (id: string) => {
    setSelectedInterests((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  const handleNextStep = async () => {
    const valid = await trigger(['fullName', 'email', 'college', 'department', 'year', 'password', 'confirmPassword', 'role']);
    if (valid) setStep(2);
  };

  const onSubmit = async (data: SignUpFormData) => {
    if (selectedInterests.length < 3) {
      toast.error('Please select at least 3 interests to personalize your feed');
      return;
    }
    setIsLoading(true);
    // BACKEND: POST /api/auth/register — create user, save interests, return JWT token
    await new Promise((r) => setTimeout(r, 1200));
    toast.success('Account created! Welcome to CampusPulse 🎉');
    await new Promise((r) => setTimeout(r, 800));
    router.push('/student-dashboard');
    setIsLoading(false);
  };

  return (
    <div className="animate-fade-in">
      <div className="mb-6">
        <h2 className="text-2xl font-800 text-foreground mb-2">
          {step === 1 ? 'Join CampusPulse' : 'Pick your interests'}
        </h2>
        <p className="text-muted-foreground text-sm">
          {step === 1
            ? 'Create your account to discover campus events' :'Select at least 3 to personalize your AI recommendations'}
        </p>
      </div>

      {/* Step Indicator */}
      <div className="flex items-center gap-2 mb-8">
        {[1, 2].map((s) => (
          <React.Fragment key={`step-indicator-${s}`}>
            <div
              className={`flex items-center justify-center w-8 h-8 rounded-full text-sm font-700 transition-all ${
                s <= step ? 'gradient-primary text-white' : 'bg-muted text-muted-foreground'
              }`}
            >
              {s < step ? <Icon name="CheckIcon" size={14} /> : s}
            </div>
            {s < 2 && (
              <div className={`flex-1 h-0.5 rounded-full transition-all ${s < step ? 'bg-primary' : 'bg-border'}`} />
            )}
          </React.Fragment>
        ))}
        <span className="text-xs text-muted-foreground ml-2">Step {step} of 2</span>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} noValidate>
        {step === 1 ? (
          <div className="space-y-4 animate-fade-in">
            {/* Role Selector */}
            <div>
              <label className="block text-sm font-600 text-foreground mb-2">I am a</label>
              <div className="grid grid-cols-2 gap-3">
                {[
                  { value: 'student', label: 'Student', icon: 'AcademicCapIcon', desc: 'Discover & attend events' },
                  { value: 'club_admin', label: 'Club Admin', icon: 'UserGroupIcon', desc: 'Create & manage events' },
                ].map((role) => {
                  const isSelected = watch('role') === role.value;
                  return (
                    <label
                      key={`role-${role.value}`}
                      className={`flex flex-col gap-1.5 p-3 rounded-xl border cursor-pointer transition-all ${
                        isSelected
                          ? 'border-primary bg-primary/10' :'border-border bg-muted hover:border-border/80'
                      }`}
                    >
                      <input
                        type="radio"
                        value={role.value}
                        className="sr-only"
                        {...register('role')}
                      />
                      <div className="flex items-center gap-2">
                        <Icon name={role.icon as any} size={16} className={isSelected ? 'text-primary' : 'text-muted-foreground'} />
                        <span className={`text-sm font-600 ${isSelected ? 'text-primary' : 'text-foreground'}`}>{role.label}</span>
                      </div>
                      <span className="text-xs text-muted-foreground">{role.desc}</span>
                    </label>
                  );
                })}
              </div>
            </div>

            {/* Full Name */}
            <div>
              <label htmlFor="signup-name" className="block text-sm font-600 text-foreground mb-1.5">Full Name</label>
              <input
                id="signup-name"
                type="text"
                placeholder="Arjun Reddy"
                className={`w-full bg-muted border rounded-xl px-4 py-3 text-sm text-foreground placeholder-muted-foreground outline-none transition-all focus:border-primary focus:ring-2 focus:ring-primary/20 ${errors.fullName ? 'border-danger' : 'border-border'}`}
                {...register('fullName', { required: 'Full name is required' })}
              />
              {errors.fullName && (
                <p className="mt-1 text-xs text-danger flex items-center gap-1">
                  <Icon name="ExclamationCircleIcon" size={12} />
                  {errors.fullName.message}
                </p>
              )}
            </div>

            {/* Email */}
            <div>
              <label htmlFor="signup-email" className="block text-sm font-600 text-foreground mb-1.5">College Email</label>
              <p className="text-xs text-muted-foreground mb-1.5">Must be your official college email</p>
              <input
                id="signup-email"
                type="email"
                placeholder="yourname@college.ac.in"
                className={`w-full bg-muted border rounded-xl px-4 py-3 text-sm text-foreground placeholder-muted-foreground outline-none transition-all focus:border-primary focus:ring-2 focus:ring-primary/20 ${errors.email ? 'border-danger' : 'border-border'}`}
                {...register('email', {
                  required: 'Email is required',
                  pattern: { value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/, message: 'Enter a valid email' },
                })}
              />
              {errors.email && (
                <p className="mt-1 text-xs text-danger flex items-center gap-1">
                  <Icon name="ExclamationCircleIcon" size={12} />
                  {errors.email.message}
                </p>
              )}
            </div>

            {/* College */}
            <div>
              <label htmlFor="signup-college" className="block text-sm font-600 text-foreground mb-1.5">College / University</label>
              <input
                id="signup-college"
                type="text"
                placeholder="VNIT Nagpur"
                className={`w-full bg-muted border rounded-xl px-4 py-3 text-sm text-foreground placeholder-muted-foreground outline-none transition-all focus:border-primary focus:ring-2 focus:ring-primary/20 ${errors.college ? 'border-danger' : 'border-border'}`}
                {...register('college', { required: 'College name is required' })}
              />
              {errors.college && (
                <p className="mt-1 text-xs text-danger flex items-center gap-1">
                  <Icon name="ExclamationCircleIcon" size={12} />
                  {errors.college.message}
                </p>
              )}
            </div>

            {/* Department + Year */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label htmlFor="signup-dept" className="block text-sm font-600 text-foreground mb-1.5">Department</label>
                <select
                  id="signup-dept"
                  className={`w-full bg-muted border rounded-xl px-4 py-3 text-sm text-foreground outline-none transition-all focus:border-primary focus:ring-2 focus:ring-primary/20 ${errors.department ? 'border-danger' : 'border-border'}`}
                  {...register('department', { required: 'Required' })}
                >
                  <option value="">Select dept.</option>
                  {departments.map((d) => (
                    <option key={`dept-${d.replace(/\s/g, '-').toLowerCase()}`} value={d}>{d}</option>
                  ))}
                </select>
                {errors.department && (
                  <p className="mt-1 text-xs text-danger">Required</p>
                )}
              </div>
              <div>
                <label htmlFor="signup-year" className="block text-sm font-600 text-foreground mb-1.5">Year</label>
                <select
                  id="signup-year"
                  className={`w-full bg-muted border rounded-xl px-4 py-3 text-sm text-foreground outline-none transition-all focus:border-primary focus:ring-2 focus:ring-primary/20 ${errors.year ? 'border-danger' : 'border-border'}`}
                  {...register('year', { required: 'Required' })}
                >
                  <option value="">Select year</option>
                  {years.map((y) => (
                    <option key={`year-${y.replace(/\s/g, '-').toLowerCase()}`} value={y}>{y}</option>
                  ))}
                </select>
                {errors.year && (
                  <p className="mt-1 text-xs text-danger">Required</p>
                )}
              </div>
            </div>

            {/* Password */}
            <div>
              <label htmlFor="signup-password" className="block text-sm font-600 text-foreground mb-1.5">Password</label>
              <div className="relative">
                <input
                  id="signup-password"
                  type={showPassword ? 'text' : 'password'}
                  placeholder="Min. 8 characters"
                  className={`w-full bg-muted border rounded-xl px-4 py-3 pr-12 text-sm text-foreground placeholder-muted-foreground outline-none transition-all focus:border-primary focus:ring-2 focus:ring-primary/20 ${errors.password ? 'border-danger' : 'border-border'}`}
                  {...register('password', {
                    required: 'Password is required',
                    minLength: { value: 8, message: 'Must be at least 8 characters' },
                  })}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-muted-foreground hover:text-foreground"
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                >
                  <Icon name={showPassword ? 'EyeSlashIcon' : 'EyeIcon'} size={18} />
                </button>
              </div>
              {errors.password && (
                <p className="mt-1 text-xs text-danger flex items-center gap-1">
                  <Icon name="ExclamationCircleIcon" size={12} />
                  {errors.password.message}
                </p>
              )}
            </div>

            {/* Confirm Password */}
            <div>
              <label htmlFor="signup-confirm" className="block text-sm font-600 text-foreground mb-1.5">Confirm Password</label>
              <input
                id="signup-confirm"
                type="password"
                placeholder="Repeat your password"
                className={`w-full bg-muted border rounded-xl px-4 py-3 text-sm text-foreground placeholder-muted-foreground outline-none transition-all focus:border-primary focus:ring-2 focus:ring-primary/20 ${errors.confirmPassword ? 'border-danger' : 'border-border'}`}
                {...register('confirmPassword', {
                  required: 'Please confirm your password',
                  validate: (v) => v === password || 'Passwords do not match',
                })}
              />
              {errors.confirmPassword && (
                <p className="mt-1 text-xs text-danger flex items-center gap-1">
                  <Icon name="ExclamationCircleIcon" size={12} />
                  {errors.confirmPassword.message}
                </p>
              )}
            </div>

            {/* Terms */}
            <label className="flex items-start gap-3 cursor-pointer">
              <input
                type="checkbox"
                className="w-4 h-4 mt-0.5 rounded border-border bg-muted accent-primary flex-shrink-0"
                {...register('agreeTerms', { required: 'You must accept the terms' })}
              />
              <span className="text-xs text-muted-foreground leading-relaxed">
                I agree to the{' '}
                <span className="text-primary hover:underline cursor-pointer">Terms of Service</span>{' '}
                and{' '}
                <span className="text-primary hover:underline cursor-pointer">Privacy Policy</span>
              </span>
            </label>
            {errors.agreeTerms && (
              <p className="text-xs text-danger flex items-center gap-1">
                <Icon name="ExclamationCircleIcon" size={12} />
                {errors.agreeTerms.message}
              </p>
            )}

            <button
              type="button"
              onClick={handleNextStep}
              className="w-full btn-primary py-3 rounded-xl text-sm font-700 flex items-center justify-center gap-2"
              style={{ minHeight: '48px' }}
            >
              Continue to Interests
              <Icon name="ArrowRightIcon" size={16} />
            </button>
          </div>
        ) : (
          <div className="space-y-5 animate-fade-in">
            {/* Interest Grid */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm text-muted-foreground">
                  Selected: <span className="text-foreground font-600">{selectedInterests.length}</span>/18
                </span>
                {selectedInterests.length >= 3 && (
                  <span className="text-xs text-success flex items-center gap-1">
                    <Icon name="CheckCircleIcon" size={12} />
                    Enough to personalize
                  </span>
                )}
              </div>
              <div className="grid grid-cols-3 gap-2 max-h-72 overflow-y-auto scrollbar-hide">
                {interestCategories.map((interest) => {
                  const isSelected = selectedInterests.includes(interest.id);
                  return (
                    <button
                      key={interest.id}
                      type="button"
                      onClick={() => toggleInterest(interest.id)}
                      className={`interest-chip flex flex-col items-center gap-1 py-3 px-2 rounded-xl text-center transition-all ${
                        isSelected ? 'selected' : ''
                      }`}
                    >
                      <span className="text-xl">{interest.emoji}</span>
                      <span className="text-xs font-500 leading-tight">{interest.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* AI Notice */}
            <div className="glass-card rounded-xl p-3 flex items-start gap-3">
              <Icon name="SparklesIcon" size={16} className="text-primary flex-shrink-0 mt-0.5" />
              <p className="text-xs text-muted-foreground leading-relaxed">
                Our AI uses your interests to surface the most relevant events from 38+ active clubs on campus. You can update these anytime from your profile.
              </p>
            </div>

            <div className="flex gap-3">
              <button
                type="button"
                onClick={() => setStep(1)}
                className="flex-1 py-3 rounded-xl text-sm font-600 border border-border text-muted-foreground hover:text-foreground hover:bg-muted transition-all flex items-center justify-center gap-2"
              >
                <Icon name="ArrowLeftIcon" size={14} />
                Back
              </button>
              <button
                type="submit"
                disabled={isLoading || selectedInterests.length < 3}
                className="flex-2 flex-1 btn-primary py-3 rounded-xl text-sm font-700 flex items-center justify-center gap-2 disabled:opacity-60 disabled:cursor-not-allowed"
                style={{ minHeight: '48px' }}
              >
                {isLoading ? (
                  <>
                    <Icon name="ArrowPathIcon" size={14} className="animate-spin" />
                    Creating account...
                  </>
                ) : (
                  <>
                    <Icon name="SparklesIcon" size={14} />
                    Join CampusPulse
                  </>
                )}
              </button>
            </div>
          </div>
        )}
      </form>

      {step === 1 && (
        <p className="text-center text-sm text-muted-foreground mt-6">
          Already have an account?{' '}
          <button onClick={onSwitchToLogin} className="text-primary font-600 hover:underline">
            Sign in
          </button>
        </p>
      )}
    </div>
  );
}