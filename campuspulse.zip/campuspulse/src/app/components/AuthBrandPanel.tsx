'use client';

import React from 'react';
import AppLogo from '@/components/ui/AppLogo';

const liveStats = [
  { label: 'Events this week', value: '47', suffix: '' },
  { label: 'Students online', value: '1.2K', suffix: '' },
  { label: 'Active clubs', value: '38', suffix: '' },
];

const recentEvents = [
  { id: 'event-brand-1', name: 'AI/ML Hackathon 2026', club: 'TechCraft Club', time: 'Live Now', color: 'bg-success' },
  { id: 'event-brand-2', name: 'Photography Walk', club: 'Lens & Light Society', time: 'In 2 hours', color: 'bg-accent' },
  { id: 'event-brand-3', name: 'Startup Pitch Night', club: 'E-Cell VNIT', time: 'Tomorrow', color: 'bg-primary' },
  { id: 'event-brand-4', name: 'Classical Music Evening', club: 'Sargam Club', time: 'Sat 6 PM', color: 'bg-warning' },
];

export default function AuthBrandPanel() {
  return (
    <div className="hidden lg:flex lg:w-[520px] xl:w-[600px] flex-shrink-0 relative overflow-hidden flex-col justify-between p-10 bg-card border-r border-border">
      {/* Background gradient blobs */}
      <div className="absolute top-0 left-0 w-72 h-72 rounded-full opacity-20 blur-3xl"
        style={{ background: 'radial-gradient(circle, #7C3AED, transparent)' }} />
      <div className="absolute bottom-0 right-0 w-64 h-64 rounded-full opacity-15 blur-3xl"
        style={{ background: 'radial-gradient(circle, #06B6D4, transparent)' }} />
      {/* Top: Logo */}
      <div className="relative z-10">
        <div className="flex items-center gap-3 mb-12">
          <AppLogo size={40} />
          <span className="font-800 text-2xl text-foreground tracking-tight">CampusPulse</span>
        </div>

        <h1 className="text-4xl font-800 text-foreground leading-tight mb-4">
          Your campus,<br />
          <span className="text-gradient-hero">alive in real time.</span>
        </h1>
        <p className="text-muted-foreground text-base leading-relaxed max-w-sm">
          AI-powered event discovery. Register, attend, and track everything happening across campus — all in one place.
        </p>
      </div>
      {/* Middle: Live Stats */}
      <div className="relative z-10 space-y-6">
        <div className="grid grid-cols-3 gap-4">
          {liveStats?.map((stat) => (
            <div key={`stat-${stat?.label?.replace(/\s/g, '-')?.toLowerCase()}`} className="glass-card rounded-2xl p-4 text-center">
              <p className="text-2xl font-800 text-foreground tabular-nums">{stat?.value}</p>
              <p className="text-xs text-muted-foreground mt-1 leading-tight">{stat?.label}</p>
            </div>
          ))}
        </div>

        {/* Live Event Feed */}
        <div className="glass-card rounded-2xl p-5 space-y-3">
          <div className="flex items-center gap-2 mb-4">
            <span className="w-2 h-2 rounded-full bg-success live-pulse" />
            <span className="text-xs font-600 text-success uppercase tracking-wider">Campus Activity Feed</span>
          </div>
          {recentEvents?.map((event) => (
            <div key={event?.id} className="flex items-center gap-3 py-2 border-b border-border last:border-0">
              <div className={`w-2 h-2 rounded-full flex-shrink-0 ${event?.color}`} />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-600 text-foreground truncate">{event?.name}</p>
                <p className="text-xs text-muted-foreground">{event?.club}</p>
              </div>
              <span className="text-xs text-muted-foreground whitespace-nowrap">{event?.time}</span>
            </div>
          ))}
        </div>
      </div>
      {/* Bottom: Social proof */}
      <div className="relative z-10">
        <div className="flex items-center gap-3">
          <div className="flex -space-x-2">
            {['#7C3AED', '#06B6D4', '#10B981', '#F59E0B']?.map((color, i) => (
              <div
                key={`avatar-brand-${i + 1}`}
                className="w-8 h-8 rounded-full border-2 border-card flex items-center justify-center text-white text-xs font-700"
                style={{ background: color }}
              >
                {['AR', 'PK', 'SM', 'RJ']?.[i]}
              </div>
            ))}
          </div>
          <p className="text-sm text-muted-foreground">
            <span className="text-foreground font-600">2,400+ students</span> already on CampusPulse
          </p>
        </div>
      </div>
    </div>
  );
}