'use client';

import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { useRouter } from 'next/navigation';
import Icon from '@/components/ui/AppIcon';
import { toast } from 'sonner';

interface LoginFormData {
  email: string;
  password: string;
  rememberMe: boolean;
}

const demoCredentials = [
  { role: 'Student', email: 'arjun.reddy@vnit.ac.in', password: 'campus@2026' },
  { role: 'Club Admin', email: 'techcraft.admin@vnit.ac.in', password: 'club@2026' },
  { role: 'Super Admin', email: 'pulse.admin@vnit.ac.in', password: 'admin@2026' },
];

interface LoginFormProps {
  onSwitchToSignup: () => void;
}

export default function LoginForm({ onSwitchToSignup }: LoginFormProps) {
  const router = useRouter();
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const {
    register,
    handleSubmit,
    setValue,
    setError,
    formState: { errors },
  } = useForm<LoginFormData>({
    defaultValues: { rememberMe: false },
  });

  const onSubmit = async (data: LoginFormData) => {
    setIsLoading(true);
    // BACKEND: POST /api/auth/login — validate credentials, return JWT token + user role
    await new Promise((r) => setTimeout(r, 1000));

    const validCred = demoCredentials.find(
      (c) => c.email === data.email && c.password === data.password
    );

    if (!validCred) {
      setError('email', { message: 'Invalid credentials — use the demo accounts below to sign in' });
      setIsLoading(false);
      return;
    }

    toast.success(`Welcome back! Redirecting to your dashboard...`);
    await new Promise((r) => setTimeout(r, 600));

    if (validCred.role === 'Student') {
      router.push('/student-dashboard');
    } else {
      router.push('/homepage');
    }
    setIsLoading(false);
  };

  const autofill = (cred: typeof demoCredentials[0]) => {
    setValue('email', cred.email);
    setValue('password', cred.password);
  };

  return (
    <div className="animate-fade-in">
      <div className="mb-8">
        <h2 className="text-2xl font-800 text-foreground mb-2">Welcome back</h2>
        <p className="text-muted-foreground text-sm">Sign in to your CampusPulse account</p>
      </div>

      {/* Social Auth */}
      <div className="grid grid-cols-2 gap-3 mb-6">
        <button className="flex items-center justify-center gap-2 py-2.5 rounded-xl border border-border bg-card hover:bg-muted transition-all text-sm font-500 text-foreground">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
            <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
            <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
            <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" fill="#FBBC05"/>
            <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
          </svg>
          <span>Google</span>
        </button>
        <button className="flex items-center justify-center gap-2 py-2.5 rounded-xl border border-border bg-card hover:bg-muted transition-all text-sm font-500 text-foreground">
          <Icon name="AcademicCapIcon" size={16} className="text-primary" />
          <span>College SSO</span>
        </button>
      </div>

      <div className="flex items-center gap-3 mb-6">
        <div className="flex-1 h-px bg-border" />
        <span className="text-xs text-muted-foreground">or continue with email</span>
        <div className="flex-1 h-px bg-border" />
      </div>

      <form onSubmit={handleSubmit(onSubmit)} noValidate className="space-y-5">
        {/* Email */}
        <div>
          <label htmlFor="login-email" className="block text-sm font-600 text-foreground mb-1.5">
            College Email
          </label>
          <p className="text-xs text-muted-foreground mb-2">Use your official college email address</p>
          <input
            id="login-email"
            type="email"
            autoComplete="email"
            placeholder="yourname@college.ac.in"
            className={`w-full bg-muted border rounded-xl px-4 py-3 text-sm text-foreground placeholder-muted-foreground outline-none transition-all focus:border-primary focus:ring-2 focus:ring-primary/20 ${
              errors.email ? 'border-danger' : 'border-border'
            }`}
            {...register('email', {
              required: 'Email is required',
              pattern: { value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/, message: 'Enter a valid email address' },
            })}
          />
          {errors.email && (
            <p className="mt-1.5 text-xs text-danger flex items-center gap-1">
              <Icon name="ExclamationCircleIcon" size={12} />
              {errors.email.message}
            </p>
          )}
        </div>

        {/* Password */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label htmlFor="login-password" className="text-sm font-600 text-foreground">
              Password
            </label>
            <button type="button" className="text-xs text-primary hover:text-primary/80 transition-colors">
              Forgot password?
            </button>
          </div>
          <div className="relative">
            <input
              id="login-password"
              type={showPassword ? 'text' : 'password'}
              autoComplete="current-password"
              placeholder="Enter your password"
              className={`w-full bg-muted border rounded-xl px-4 py-3 pr-12 text-sm text-foreground placeholder-muted-foreground outline-none transition-all focus:border-primary focus:ring-2 focus:ring-primary/20 ${
                errors.password ? 'border-danger' : 'border-border'
              }`}
              {...register('password', {
                required: 'Password is required',
                minLength: { value: 6, message: 'Password must be at least 6 characters' },
              })}
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-muted-foreground hover:text-foreground transition-colors"
              aria-label={showPassword ? 'Hide password' : 'Show password'}
            >
              <Icon name={showPassword ? 'EyeSlashIcon' : 'EyeIcon'} size={18} />
            </button>
          </div>
          {errors.password && (
            <p className="mt-1.5 text-xs text-danger flex items-center gap-1">
              <Icon name="ExclamationCircleIcon" size={12} />
              {errors.password.message}
            </p>
          )}
        </div>

        {/* Remember Me */}
        <label className="flex items-center gap-3 cursor-pointer">
          <input
            type="checkbox"
            className="w-4 h-4 rounded border-border bg-muted checked:bg-primary checked:border-primary outline-none accent-primary"
            {...register('rememberMe')}
          />
          <span className="text-sm text-muted-foreground">Keep me signed in for 30 days</span>
        </label>

        {/* Submit */}
        <button
          type="submit"
          disabled={isLoading}
          className="w-full btn-primary py-3 rounded-xl text-sm font-700 flex items-center justify-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed"
          style={{ minHeight: '48px' }}
        >
          {isLoading ? (
            <>
              <Icon name="ArrowPathIcon" size={16} className="animate-spin" />
              <span>Signing in...</span>
            </>
          ) : (
            'Sign In to CampusPulse'
          )}
        </button>
      </form>

      <p className="text-center text-sm text-muted-foreground mt-6">
        New to CampusPulse?{' '}
        <button onClick={onSwitchToSignup} className="text-primary font-600 hover:underline">
          Create your account
        </button>
      </p>

      {/* Demo Credentials */}
      <div className="mt-8 glass-card rounded-2xl p-4">
        <div className="flex items-center gap-2 mb-3">
          <Icon name="KeyIcon" size={14} className="text-warning" />
          <p className="text-xs font-700 text-warning uppercase tracking-wider">Demo Credentials</p>
        </div>
        <div className="space-y-2">
          {demoCredentials.map((cred) => (
            <div
              key={`demo-${cred.role.toLowerCase().replace(/\s/g, '-')}`}
              className="flex items-center justify-between bg-muted rounded-xl px-3 py-2"
            >
              <div className="min-w-0">
                <p className="text-xs font-600 text-foreground">{cred.role}</p>
                <p className="text-xs text-muted-foreground truncate">{cred.email}</p>
              </div>
              <button
                type="button"
                onClick={() => autofill(cred)}
                className="text-xs text-primary font-600 hover:text-primary/80 transition-colors flex-shrink-0 ml-2 flex items-center gap-1"
              >
                <Icon name="ArrowRightIcon" size={12} />
                Use
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}