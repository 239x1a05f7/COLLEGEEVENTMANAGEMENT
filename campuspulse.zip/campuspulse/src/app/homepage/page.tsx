import React from 'react';
import AppLayout from '@/components/AppLayout';
import HeroBannerCarousel from './components/HeroBannerCarousel';
import LiveEventsStrip from './components/LiveEventsStrip';
import CategoryFilterBar from './components/CategoryFilterBar';
import TrendingEventsGrid from './components/TrendingEventsGrid';
import AIRecommendationsRow from './components/AIRecommendationsRow';
import ClubSpotlightSidebar from './components/ClubSpotlightSidebar';
import UpcomingThisWeek from './components/UpcomingThisWeek';

export default function HomepagePage() {
  return (
    <AppLayout activePath="/homepage">
      <div className="space-y-8">
        {/* Hero Banner */}
        <HeroBannerCarousel />

        {/* Live Events Strip */}
        <LiveEventsStrip />

        {/* Category Filters + Main Grid + Sidebar */}
        <div className="grid grid-cols-1 xl:grid-cols-4 2xl:grid-cols-4 gap-6">
          {/* Main Content */}
          <div className="xl:col-span-3 space-y-6">
            <CategoryFilterBar />
            <AIRecommendationsRow />
            <TrendingEventsGrid />
            <UpcomingThisWeek />
          </div>

          {/* Sidebar */}
          <div className="xl:col-span-1">
            <ClubSpotlightSidebar />
          </div>
        </div>
      </div>
    </AppLayout>
  );
}