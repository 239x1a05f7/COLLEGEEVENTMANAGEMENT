'use client';

import React from 'react';
import EventCard, { EventCardData } from '@/components/ui/EventCard';
import Icon from '@/components/ui/AppIcon';

const trendingEvents: EventCardData[] = [
{
  id: 'event-001',
  title: 'National Level Hackathon 2026 — Build AI for Bharat',
  club: 'TechCraft Club',
  clubLogo: '',
  banner: "https://img.rocket.new/generatedImages/rocket_gen_img_14331839a-1767826107682.png",
  bannerAlt: 'Multiple developers working together at computers during a hackathon event',
  category: 'Technology',
  date: 'May 15–17, 2026',
  time: '9:00 AM',
  location: 'Computer Center, Block A',
  registrations: 342,
  capacity: 400,
  status: 'upcoming',
  isFree: true,
  isTrending: true,
  aiMatchScore: 96,
  tags: ['hackathon', 'AI', 'coding', 'prizes']
},
{
  id: 'event-002',
  title: 'TEDx VNIT 2026: Reimagine Tomorrow',
  club: 'TED Club VNIT',
  clubLogo: '',
  banner: "https://img.rocket.new/generatedImages/rocket_gen_img_16595d555-1772146306437.png",
  bannerAlt: 'Speaker on stage at TED event with spotlight and audience in background',
  category: 'Talks & Conferences',
  date: 'May 22, 2026',
  time: '3:00 PM',
  location: 'Main Auditorium',
  registrations: 487,
  capacity: 500,
  status: 'upcoming',
  isFree: false,
  price: 150,
  isTrending: true,
  tags: ['TEDx', 'talks', 'innovation', 'leadership']
},
{
  id: 'event-003',
  title: 'UI/UX Design Sprint — Figma to Prototype in 4 Hours',
  club: 'Design Collective',
  clubLogo: '',
  banner: "https://img.rocket.new/generatedImages/rocket_gen_img_17a4d94f8-1773204330326.png",
  bannerAlt: 'Designer creating UI wireframes on laptop with colorful design tools visible',
  category: 'Design',
  date: 'May 14, 2026',
  time: '2:00 PM',
  location: 'Innovation Lab, Block B',
  registrations: 78,
  capacity: 100,
  status: 'upcoming',
  isFree: true,
  aiMatchScore: 91,
  tags: ['design', 'figma', 'UX', 'workshop']
},
{
  id: 'event-004',
  title: 'Startup Weekend VNIT — 54-Hour Challenge',
  club: 'E-Cell VNIT',
  clubLogo: '',
  banner: "https://img.rocket.new/generatedImages/rocket_gen_img_1cd2dfa92-1772871562490.png",
  bannerAlt: 'Startup team presenting business pitch to panel of judges in conference room',
  category: 'Entrepreneurship',
  date: 'May 16–18, 2026',
  time: '9:00 AM',
  location: 'Seminar Complex',
  registrations: 203,
  capacity: 250,
  status: 'upcoming',
  isFree: false,
  price: 299,
  isTrending: true,
  tags: ['startup', 'entrepreneurship', 'pitch', 'networking']
},
{
  id: 'event-005',
  title: 'Inter-College Basketball Tournament 2026',
  club: 'Sports Council VNIT',
  clubLogo: '',
  banner: "https://images.unsplash.com/photo-1710806587784-047ac1f83cd6",
  bannerAlt: 'Basketball players competing in an indoor gymnasium with spectators in stands',
  category: 'Sports',
  date: 'May 18–20, 2026',
  time: '8:00 AM',
  location: 'Sports Complex',
  registrations: 156,
  capacity: 200,
  status: 'upcoming',
  isFree: true,
  tags: ['basketball', 'sports', 'tournament', 'inter-college']
},
{
  id: 'event-006',
  title: 'Photography Walk — Monsoon Campus Edition',
  club: 'Lens & Light Society',
  clubLogo: '',
  banner: "https://img.rocket.new/generatedImages/rocket_gen_img_1f156d638-1773121089746.png",
  bannerAlt: 'Photographer taking photos of campus architecture during golden hour lighting',
  category: 'Photography',
  date: 'May 11, 2026',
  time: '6:00 AM',
  location: 'Main Gate, VNIT Campus',
  registrations: 44,
  capacity: 50,
  status: 'upcoming',
  isFree: true,
  tags: ['photography', 'walk', 'campus', 'nature']
}];


export default function TrendingEventsGrid() {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Icon name="FireIcon" size={18} className="text-warning" />
          <h2 className="text-base font-700 text-foreground">Trending Events</h2>
        </div>
        <button className="text-xs text-primary font-600 hover:underline flex items-center gap-1">
          View all
          <Icon name="ArrowRightIcon" size={12} />
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-3 gap-4">
        {trendingEvents.map((event) =>
        <EventCard key={event.id} event={event} />
        )}
      </div>
    </div>);

}