'use client';

import React from 'react';
import Icon from '@/components/ui/AppIcon';
import AppImage from '@/components/ui/AppImage';

import { toast } from 'sonner';

const aiRecs = [
{
  id: 'airec-1',
  title: 'Open Source Sprint — Build for Bharat',
  club: 'OSS Circle',
  date: 'May 12, 2026',
  time: '10:00 AM',
  matchScore: 96,
  reason: 'Matches your AI/ML and Technology interests',
  banner: "https://images.unsplash.com/photo-1518933165971-611dbc9c412d",
  bannerAlt: 'Code on dark screen with colorful syntax highlighting showing an open source project',
  isFree: true,
  registrations: 112,
  capacity: 150
},
{
  id: 'airec-2',
  title: 'UI/UX Design Bootcamp — Figma to Production',
  club: 'Design Collective',
  date: 'May 14, 2026',
  time: '2:00 PM',
  matchScore: 91,
  reason: 'Based on your Design interest and browsing history',
  banner: "https://img.rocket.new/generatedImages/rocket_gen_img_118984791-1772139412892.png",
  bannerAlt: 'Designer working on a laptop with colorful Figma interface showing UI components',
  isFree: true,
  registrations: 78,
  capacity: 100
},
{
  id: 'airec-3',
  title: 'Startup Weekend VNIT 2026',
  club: 'E-Cell VNIT',
  date: 'May 16–18, 2026',
  time: '9:00 AM',
  matchScore: 88,
  reason: 'Trending among CS students like you',
  banner: "https://images.unsplash.com/photo-1552664730-d307ca884978",
  bannerAlt: 'Team of young entrepreneurs brainstorming around a whiteboard with sticky notes',
  isFree: false,
  price: 299,
  registrations: 203,
  capacity: 250
},
{
  id: 'airec-4',
  title: 'Machine Learning Paper Reading Club',
  club: 'AI Research Society',
  date: 'May 11, 2026',
  time: '5:00 PM',
  matchScore: 85,
  reason: 'Matches your AI/ML interest',
  banner: "https://img.rocket.new/generatedImages/rocket_gen_img_1b9b78950-1774149821493.png",
  bannerAlt: 'Neural network visualization with glowing nodes and connections on dark background',
  isFree: true,
  registrations: 45,
  capacity: 60
}];


export default function AIRecommendationsRow() {
  const handleRegister = (eventId: string, eventName: string) => {
    // BACKEND: POST /api/events/{eventId}/register
    toast.success(`Registered for ${eventName}!`);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg gradient-primary flex items-center justify-center">
            <Icon name="SparklesIcon" size={14} className="text-white" />
          </div>
          <div>
            <h2 className="text-base font-700 text-foreground">AI Picks for You</h2>
            <p className="text-xs text-muted-foreground">Personalized based on your interests & activity</p>
          </div>
        </div>
        <button className="text-xs text-primary font-600 hover:underline flex items-center gap-1">
          Refresh
          <Icon name="ArrowPathIcon" size={12} />
        </button>
      </div>

      <div className="flex gap-4 overflow-x-auto scrollbar-hide pb-2">
        {aiRecs.map((rec) => {
          const capacityPct = Math.round(rec.registrations / rec.capacity * 100);
          return (
            <div
              key={rec.id}
              className="flex-shrink-0 w-72 glass-card rounded-2xl overflow-hidden hover:border-primary/30 transition-all group cursor-pointer">
              
              {/* Banner */}
              <div className="relative h-36 overflow-hidden">
                <AppImage
                  src={rec.banner}
                  alt={rec.bannerAlt}
                  fill
                  className="object-cover group-hover:scale-105 transition-transform duration-500"
                  sizes="288px" />
                
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
                {/* Match Score */}
                <div className="absolute top-2 right-2 flex items-center gap-1 bg-primary/90 backdrop-blur-sm text-white text-xs font-700 px-2.5 py-1 rounded-full">
                  <Icon name="SparklesIcon" size={10} />
                  {rec.matchScore}% match
                </div>
              </div>

              <div className="p-4 space-y-3">
                <div>
                  <h3 className="text-sm font-700 text-foreground leading-snug line-clamp-2">{rec.title}</h3>
                  <p className="text-xs text-primary mt-1 font-500">{rec.club}</p>
                </div>

                {/* AI Reason */}
                <div className="flex items-start gap-2 bg-primary/5 border border-primary/10 rounded-lg p-2">
                  <Icon name="LightBulbIcon" size={12} className="text-primary flex-shrink-0 mt-0.5" />
                  <p className="text-xs text-muted-foreground leading-relaxed">{rec.reason}</p>
                </div>

                <div className="flex items-center gap-3 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <Icon name="CalendarIcon" size={11} />
                    {rec.date}
                  </span>
                  <span className="flex items-center gap-1">
                    <Icon name="ClockIcon" size={11} />
                    {rec.time}
                  </span>
                </div>

                {/* Capacity */}
                <div className="space-y-1">
                  <div className="h-1 bg-muted rounded-full overflow-hidden">
                    <div
                      className="h-full bg-primary rounded-full"
                      style={{ width: `${capacityPct}%` }} />
                    
                  </div>
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>{rec.registrations} registered</span>
                    <span className={rec.isFree ? 'text-success font-600' : 'text-accent font-600'}>
                      {rec.isFree ? 'Free' : `₹${rec.price}`}
                    </span>
                  </div>
                </div>

                <button
                  onClick={() => handleRegister(rec.id, rec.title)}
                  className="w-full py-2 rounded-xl text-xs font-600 btn-primary flex items-center justify-center gap-1.5">
                  
                  <Icon name="BoltIcon" size={12} />
                  Quick Register
                </button>
              </div>
            </div>);

        })}
      </div>
    </div>);

}