'use client';

import React, { useState } from 'react';
import Icon from '@/components/ui/AppIcon';
import { toast } from 'sonner';

const clubs = [
  { id: 'club-001', name: 'TechCraft Club', category: 'Technology', members: 342, events: 12, rating: 4.9, isFollowing: true, color: 'bg-primary', initials: 'TC', activeEvents: 2 },
  { id: 'club-002', name: 'E-Cell VNIT', category: 'Entrepreneurship', members: 289, events: 8, rating: 4.8, isFollowing: true, color: 'bg-accent', initials: 'EC', activeEvents: 1 },
  { id: 'club-003', name: 'Design Collective', category: 'Design', members: 178, events: 6, rating: 4.7, isFollowing: false, color: 'bg-warning', initials: 'DC', activeEvents: 0 },
  { id: 'club-004', name: 'Sargam Music Club', category: 'Music', members: 256, events: 9, rating: 4.6, isFollowing: false, color: 'bg-success', initials: 'SM', activeEvents: 1 },
  { id: 'club-005', name: 'Lens & Light Society', category: 'Photography', members: 134, events: 5, rating: 4.5, isFollowing: false, color: 'bg-danger', initials: 'LL', activeEvents: 0 },
  { id: 'club-006', name: 'AI Research Society', category: 'AI & ML', members: 198, events: 7, rating: 4.8, isFollowing: false, color: 'bg-violet-500', initials: 'AI', activeEvents: 0 },
];

const announcements = [
  { id: 'ann-1', club: 'TechCraft Club', message: 'Hackathon registrations close in 48 hours! 58 spots remaining.', time: '10m ago', urgent: true },
  { id: 'ann-2', club: 'E-Cell VNIT', message: 'Startup Weekend mentors announced — check the event page for details.', time: '1h ago', urgent: false },
  { id: 'ann-3', club: 'Design Collective', message: 'Design Sprint rescheduled to May 14. Same time, same venue.', time: '3h ago', urgent: false },
  { id: 'ann-4', club: 'Sargam Music Club', message: 'Tonight\'s performance starts at 7 PM. Gates open at 6:30 PM.', time: '5h ago', urgent: true },
];

export default function ClubSpotlightSidebar() {
  const [followState, setFollowState] = useState<Record<string, boolean>>(
    Object.fromEntries(clubs.map((c) => [c.id, c.isFollowing]))
  );
  const [activeTab, setActiveTab] = useState<'clubs' | 'announcements'>('clubs');

  const toggleFollow = (clubId: string, clubName: string) => {
    setFollowState((prev) => {
      const newVal = !prev[clubId];
      // BACKEND: POST /api/clubs/{clubId}/follow or unfollow
      toast.success(newVal ? `Following ${clubName}` : `Unfollowed ${clubName}`);
      return { ...prev, [clubId]: newVal };
    });
  };

  return (
    <div className="space-y-4 sticky top-4">
      {/* Tab Switcher */}
      <div className="flex bg-muted rounded-xl p-1">
        <button
          onClick={() => setActiveTab('clubs')}
          className={`flex-1 py-2 text-xs font-600 rounded-lg transition-all ${
            activeTab === 'clubs' ? 'bg-card text-foreground' : 'text-muted-foreground hover:text-foreground'
          }`}
        >
          Active Clubs
        </button>
        <button
          onClick={() => setActiveTab('announcements')}
          className={`flex-1 py-2 text-xs font-600 rounded-lg transition-all relative ${
            activeTab === 'announcements' ? 'bg-card text-foreground' : 'text-muted-foreground hover:text-foreground'
          }`}
        >
          Announcements
          <span className="ml-1 bg-danger text-white text-xs rounded-full px-1.5 py-0.5 font-700">2</span>
        </button>
      </div>

      {activeTab === 'clubs' ? (
        <div className="glass-card rounded-2xl overflow-hidden">
          <div className="p-4 border-b border-border">
            <h3 className="text-sm font-700 text-foreground">Top Clubs This Week</h3>
            <p className="text-xs text-muted-foreground mt-0.5">By event activity & engagement</p>
          </div>
          <div className="divide-y divide-border">
            {clubs.map((club, i) => (
              <div key={club.id} className="flex items-center gap-3 p-3 hover:bg-muted/30 transition-colors">
                <span className="text-xs text-muted-foreground w-4 flex-shrink-0 tabular-nums">#{i + 1}</span>
                <div className={`w-9 h-9 rounded-xl ${club.color} flex items-center justify-center text-white text-xs font-700 flex-shrink-0`}>
                  {club.initials}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5">
                    <p className="text-xs font-600 text-foreground truncate">{club.name}</p>
                    {club.activeEvents > 0 && (
                      <span className="w-1.5 h-1.5 rounded-full bg-success live-pulse flex-shrink-0" />
                    )}
                  </div>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className="text-xs text-muted-foreground">{club.members} members</span>
                    <span className="text-xs text-warning flex items-center gap-0.5">
                      <Icon name="StarIcon" size={10} variant="solid" />
                      {club.rating}
                    </span>
                  </div>
                </div>
                <button
                  onClick={() => toggleFollow(club.id, club.name)}
                  className={`flex-shrink-0 px-2.5 py-1.5 rounded-lg text-xs font-600 transition-all ${
                    followState[club.id]
                      ? 'bg-primary/10 text-primary border border-primary/20' :'bg-muted text-muted-foreground hover:text-foreground border border-border'
                  }`}
                >
                  {followState[club.id] ? 'Following' : 'Follow'}
                </button>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div className="glass-card rounded-2xl overflow-hidden">
          <div className="p-4 border-b border-border">
            <h3 className="text-sm font-700 text-foreground">Club Announcements</h3>
            <p className="text-xs text-muted-foreground mt-0.5">From clubs you follow</p>
          </div>
          <div className="divide-y divide-border">
            {announcements.map((ann) => (
              <div key={ann.id} className="p-4 hover:bg-muted/30 transition-colors">
                <div className="flex items-start justify-between gap-2 mb-2">
                  <span className="text-xs font-600 text-primary">{ann.club}</span>
                  <div className="flex items-center gap-1 flex-shrink-0">
                    {ann.urgent && (
                      <span className="text-xs bg-danger/10 text-danger border border-danger/20 px-1.5 py-0.5 rounded-full font-600">Urgent</span>
                    )}
                    <span className="text-xs text-muted-foreground">{ann.time}</span>
                  </div>
                </div>
                <p className="text-xs text-muted-foreground leading-relaxed">{ann.message}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Quick Stats */}
      <div className="glass-card rounded-2xl p-4 space-y-3">
        <h3 className="text-sm font-700 text-foreground">Campus Pulse Today</h3>
        <div className="grid grid-cols-2 gap-3">
          {[
            { label: 'Events Today', value: '11', icon: 'CalendarIcon', color: 'text-primary' },
            { label: 'Live Now', value: '4', icon: 'BoltIcon', color: 'text-success' },
            { label: 'Total Registrations', value: '1.8K', icon: 'UserGroupIcon', color: 'text-accent' },
            { label: 'Active Clubs', value: '38', icon: 'StarIcon', color: 'text-warning' },
          ].map((stat) => (
            <div key={`quick-stat-${stat.label.replace(/\s/g, '-').toLowerCase()}`} className="bg-muted rounded-xl p-3 text-center">
              <Icon name={stat.icon as any} size={16} className={`${stat.color} mx-auto mb-1`} />
              <p className="text-lg font-800 text-foreground tabular-nums">{stat.value}</p>
              <p className="text-xs text-muted-foreground leading-tight">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}