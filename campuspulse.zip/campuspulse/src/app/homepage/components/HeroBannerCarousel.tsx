'use client';

import React, { useState, useEffect } from 'react';
import AppImage from '@/components/ui/AppImage';
import Icon from '@/components/ui/AppIcon';
import StatusBadge from '@/components/ui/StatusBadge';
import { toast } from 'sonner';

const featuredEvents = [
{
  id: 'featured-1',
  title: 'National Level Hackathon 2026',
  subtitle: 'Build AI solutions for real-world campus problems. 72-hour challenge.',
  club: 'TechCraft Club',
  category: 'Technology',
  date: 'May 15–17, 2026',
  location: 'Computer Center, Block A',
  registrations: 342,
  capacity: 400,
  status: 'upcoming' as const,
  isFree: true,
  banner: "https://img.rocket.new/generatedImages/rocket_gen_img_162b5396b-1771510329482.png",
  bannerAlt: 'Developers collaborating at workstations during a hackathon with multiple screens showing code',
  gradient: 'from-violet-900/90 via-violet-800/60 to-transparent',
  accentColor: 'text-violet-300'
},
{
  id: 'featured-2',
  title: 'TEDx VNIT 2026: Reimagine Tomorrow',
  subtitle: 'An independently organized TED event featuring 12 campus thought leaders.',
  club: 'TED Club VNIT',
  category: 'Talks & Conferences',
  date: 'May 22, 2026',
  location: 'Main Auditorium',
  registrations: 487,
  capacity: 500,
  status: 'upcoming' as const,
  isFree: false,
  price: 150,
  banner: "https://img.rocket.new/generatedImages/rocket_gen_img_1c8f8be08-1772156345603.png",
  bannerAlt: 'Speaker presenting on stage at a TED-style conference with red circle backdrop and large audience',
  gradient: 'from-red-900/90 via-red-800/60 to-transparent',
  accentColor: 'text-red-300'
},
{
  id: 'featured-3',
  title: 'Sargam — Classical Music Night',
  subtitle: 'An evening of Hindustani classical ragas by campus artists and guest performers.',
  club: 'Sargam Music Club',
  category: 'Music & Arts',
  date: 'May 10, 2026',
  location: 'Open Air Theatre',
  registrations: 218,
  capacity: 300,
  status: 'live' as const,
  isFree: true,
  banner: "https://img.rocket.new/generatedImages/rocket_gen_img_1638e11e9-1772801498805.png",
  bannerAlt: 'Classical musician playing sitar on stage with warm amber stage lighting and seated audience',
  gradient: 'from-amber-900/90 via-amber-800/60 to-transparent',
  accentColor: 'text-amber-300'
}];


export default function HeroBannerCarousel() {
  const [activeIdx, setActiveIdx] = useState(0);
  const [isRegistering, setIsRegistering] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveIdx((prev) => (prev + 1) % featuredEvents.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  const current = featuredEvents[activeIdx];
  const capacityPct = Math.round(current.registrations / current.capacity * 100);

  const handleRegister = async () => {
    setIsRegistering(true);
    // BACKEND: POST /api/events/{current.id}/register
    await new Promise((r) => setTimeout(r, 900));
    setIsRegistering(false);
    toast.success(`Registered for ${current.title}! Check My Events for your QR code.`);
  };

  return (
    <div className="relative h-80 md:h-96 rounded-3xl overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0">
        <AppImage
          src={current.banner}
          alt={current.bannerAlt}
          fill
          priority
          className="object-cover transition-all duration-700"
          sizes="(max-width: 768px) 100vw, 90vw" />
        
        <div className={`absolute inset-0 bg-gradient-to-r ${current.gradient}`} />
      </div>

      {/* Content */}
      <div className="relative z-10 h-full flex flex-col justify-between p-6 md:p-8">
        {/* Top */}
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-2">
            <StatusBadge variant={current.status} pulse={current.status === 'live'} />
            <span className="text-white/70 text-sm font-500 bg-black/30 backdrop-blur-sm px-3 py-1 rounded-full">
              {current.category}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-white/70 text-sm bg-black/30 backdrop-blur-sm px-3 py-1 rounded-full flex items-center gap-1.5">
              <Icon name="UserGroupIcon" size={14} />
              {current.registrations.toLocaleString()} registered
            </span>
          </div>
        </div>

        {/* Bottom */}
        <div className="space-y-4">
          <div>
            <p className={`text-sm font-600 mb-2 ${current.accentColor}`}>{current.club}</p>
            <h2 className="text-2xl md:text-3xl font-800 text-white leading-tight mb-2 max-w-xl">
              {current.title}
            </h2>
            <p className="text-white/70 text-sm leading-relaxed max-w-lg hidden md:block">
              {current.subtitle}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-1.5 text-white/70 text-sm">
              <Icon name="CalendarIcon" size={14} />
              <span>{current.date}</span>
            </div>
            <div className="flex items-center gap-1.5 text-white/70 text-sm">
              <Icon name="MapPinIcon" size={14} />
              <span>{current.location}</span>
            </div>
            <div className="flex items-center gap-1.5 text-white/70 text-sm">
              <Icon name="TicketIcon" size={14} />
              <span>{current.isFree ? 'Free Entry' : `₹${current.price}`}</span>
            </div>
          </div>

          {/* Capacity Bar */}
          <div className="max-w-sm space-y-1">
            <div className="flex justify-between text-xs text-white/60">
              <span>{capacityPct}% filled</span>
              <span>{current.capacity - current.registrations} spots left</span>
            </div>
            <div className="h-1.5 bg-white/20 rounded-full overflow-hidden">
              <div
                className="h-full bg-white/80 rounded-full transition-all"
                style={{ width: `${capacityPct}%` }} />
              
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleRegister}
              disabled={isRegistering}
              className="flex items-center gap-2 bg-white text-zinc-900 hover:bg-white/90 active:scale-95 transition-all px-5 py-2.5 rounded-xl text-sm font-700 disabled:opacity-70">
              
              {isRegistering ?
              <><Icon name="ArrowPathIcon" size={14} className="animate-spin" />Registering...</> :

              <><Icon name="BoltIcon" size={14} />Register Now</>
              }
            </button>
            <button className="flex items-center gap-2 bg-white/10 backdrop-blur-sm hover:bg-white/20 text-white px-4 py-2.5 rounded-xl text-sm font-600 transition-all border border-white/20">
              <Icon name="InformationCircleIcon" size={14} />
              View Details
            </button>
          </div>
        </div>
      </div>

      {/* Slide Indicators */}
      <div className="absolute bottom-4 right-6 flex items-center gap-2 z-10">
        {featuredEvents.map((_, i) =>
        <button
          key={`carousel-dot-${i + 1}`}
          onClick={() => setActiveIdx(i)}
          className={`rounded-full transition-all duration-300 ${
          i === activeIdx ? 'w-6 h-2 bg-white' : 'w-2 h-2 bg-white/40 hover:bg-white/60'}`
          }
          aria-label={`Go to slide ${i + 1}`} />

        )}
      </div>

      {/* Prev/Next */}
      <button
        onClick={() => setActiveIdx((prev) => (prev - 1 + featuredEvents.length) % featuredEvents.length)}
        className="absolute left-4 top-1/2 -translate-y-1/2 z-10 p-2 rounded-full bg-black/30 backdrop-blur-sm text-white hover:bg-black/50 transition-all"
        aria-label="Previous slide">
        
        <Icon name="ChevronLeftIcon" size={18} />
      </button>
      <button
        onClick={() => setActiveIdx((prev) => (prev + 1) % featuredEvents.length)}
        className="absolute right-4 top-1/2 -translate-y-1/2 z-10 p-2 rounded-full bg-black/30 backdrop-blur-sm text-white hover:bg-black/50 transition-all"
        aria-label="Next slide">
        
        <Icon name="ChevronRightIcon" size={18} />
      </button>
    </div>);

}