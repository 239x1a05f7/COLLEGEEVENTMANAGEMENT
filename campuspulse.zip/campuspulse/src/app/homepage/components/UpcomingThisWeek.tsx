import React from 'react';
import Icon from '@/components/ui/AppIcon';
import StatusBadge from '@/components/ui/StatusBadge';

const upcomingEvents = [
  { id: 'upcoming-1', title: 'Robotics Workshop — ROS2 Basics', club: 'Robotics Society', date: 'Today', time: '4:00 PM', location: 'ECE Lab 3', category: 'Robotics', isFree: true, registrations: 28, capacity: 35 },
  { id: 'upcoming-2', title: 'Classical Debate — AI Ethics', club: 'Debate Club', date: 'Today', time: '6:00 PM', location: 'Seminar Hall 2', category: 'Debate', isFree: true, registrations: 45, capacity: 80 },
  { id: 'upcoming-3', title: 'Bollywood Dance Auditions', club: 'Nritya Dance Club', date: 'Tomorrow', time: '10:00 AM', location: 'Dance Studio', category: 'Dance', isFree: true, registrations: 62, capacity: 75 },
  { id: 'upcoming-4', title: 'Campus Finance & Investment Talk', club: 'Finance Club', date: 'May 10', time: '3:00 PM', location: 'LH-1', category: 'Finance', isFree: true, registrations: 89, capacity: 120 },
  { id: 'upcoming-5', title: 'Short Film Screening Night', club: 'Cine Society', date: 'May 10', time: '7:00 PM', location: 'Open Air Theatre', category: 'Film', isFree: true, registrations: 134, capacity: 200 },
  { id: 'upcoming-6', title: 'Inter-Hostel Badminton', club: 'Sports Council', date: 'May 11', time: '8:00 AM', location: 'Badminton Court', category: 'Sports', isFree: true, registrations: 48, capacity: 64 },
];

export default function UpcomingThisWeek() {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Icon name="CalendarDaysIcon" size={18} className="text-accent" />
          <h2 className="text-base font-700 text-foreground">Upcoming This Week</h2>
        </div>
        <button className="text-xs text-primary font-600 hover:underline flex items-center gap-1">
          Full calendar
          <Icon name="ArrowRightIcon" size={12} />
        </button>
      </div>
      <div className="glass-card rounded-2xl overflow-hidden">
        <div className="divide-y divide-border">
          {upcomingEvents?.map((event) => {
            const capacityPct = Math.round((event?.registrations / event?.capacity) * 100);
            const isAlmostFull = capacityPct >= 80;
            return (
              <div key={event?.id} className="flex items-center gap-4 p-4 hover:bg-muted/30 transition-colors group cursor-pointer">
                {/* Date Badge */}
                <div className="flex-shrink-0 w-14 text-center">
                  <p className="text-xs font-700 text-primary">{event?.date}</p>
                  <p className="text-xs text-muted-foreground">{event?.time}</p>
                </div>
                {/* Divider */}
                <div className="w-px h-10 bg-border flex-shrink-0" />
                {/* Content */}
                <div className="flex-1 min-w-0">
                  <h3 className="text-sm font-600 text-foreground truncate group-hover:text-primary transition-colors">
                    {event?.title}
                  </h3>
                  <div className="flex items-center gap-3 mt-1">
                    <span className="text-xs text-muted-foreground">{event?.club}</span>
                    <span className="text-xs text-muted-foreground flex items-center gap-1">
                      <Icon name="MapPinIcon" size={10} />
                      {event?.location}
                    </span>
                  </div>
                </div>
                {/* Capacity */}
                <div className="hidden sm:flex flex-col items-end gap-1 flex-shrink-0 w-24">
                  <span className={`text-xs font-600 ${isAlmostFull ? 'text-warning' : 'text-muted-foreground'}`}>
                    {event?.capacity - event?.registrations} left
                  </span>
                  <div className="w-full h-1 bg-muted rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full ${isAlmostFull ? 'bg-warning' : 'bg-primary'}`}
                      style={{ width: `${capacityPct}%` }}
                    />
                  </div>
                </div>
                {/* Category */}
                <div className="hidden md:block flex-shrink-0">
                  <StatusBadge variant="upcoming" label={event?.category} />
                </div>
                {/* Register */}
                <button className="flex-shrink-0 text-xs text-primary font-600 hover:underline transition-colors">
                  Register
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}