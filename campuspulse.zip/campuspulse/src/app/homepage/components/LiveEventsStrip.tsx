'use client';

import React from 'react';
import Icon from '@/components/ui/AppIcon';

const liveEvents = [
  { id: 'live-1', name: 'AI/ML Hackathon — Day 2', club: 'TechCraft Club', attendees: 87, location: 'Computer Center', timeLeft: '14h 22m left' },
  { id: 'live-2', name: 'Sargam Classical Night', club: 'Sargam Club', attendees: 218, location: 'Open Air Theatre', timeLeft: '2h 10m left' },
  { id: 'live-3', name: 'Photography Exhibition', club: 'Lens & Light', attendees: 64, location: 'Gallery Hall', timeLeft: '5h 45m left' },
  { id: 'live-4', name: 'Startup Pitch Practice', club: 'E-Cell VNIT', attendees: 31, location: 'Seminar Room 3', timeLeft: '1h 05m left' },
];

export default function LiveEventsStrip() {
  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-success live-pulse" />
          <h2 className="text-base font-700 text-foreground">Live Right Now</h2>
          <span className="text-xs bg-success/10 text-success border border-success/20 px-2 py-0.5 rounded-full font-600">
            {liveEvents?.length} events
          </span>
        </div>
        <button className="text-xs text-primary font-600 hover:underline flex items-center gap-1">
          View all
          <Icon name="ArrowRightIcon" size={12} />
        </button>
      </div>
      <div className="flex gap-3 overflow-x-auto scrollbar-hide pb-1">
        {liveEvents?.map((event) => (
          <div
            key={event?.id}
            className="flex-shrink-0 w-64 glass-card rounded-2xl p-4 border-success/20 hover:border-success/40 transition-all cursor-pointer group"
          >
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-success live-pulse" />
                <span className="text-xs font-600 text-success">LIVE</span>
              </div>
              <span className="text-xs text-muted-foreground bg-muted px-2 py-0.5 rounded-full">{event?.timeLeft}</span>
            </div>
            <h3 className="text-sm font-700 text-foreground mb-1 leading-snug group-hover:text-success transition-colors line-clamp-2">
              {event?.name}
            </h3>
            <p className="text-xs text-muted-foreground mb-3">{event?.club}</p>
            <div className="flex items-center justify-between text-xs text-muted-foreground">
              <div className="flex items-center gap-1">
                <Icon name="UserGroupIcon" size={12} />
                <span>{event?.attendees} attending</span>
              </div>
              <div className="flex items-center gap-1">
                <Icon name="MapPinIcon" size={12} />
                <span className="truncate max-w-24">{event?.location}</span>
              </div>
            </div>
            <button className="mt-3 w-full py-2 rounded-xl text-xs font-600 bg-success/10 text-success border border-success/20 hover:bg-success/20 transition-all flex items-center justify-center gap-1.5">
              <Icon name="ArrowTopRightOnSquareIcon" size={12} />
              Join Now
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}