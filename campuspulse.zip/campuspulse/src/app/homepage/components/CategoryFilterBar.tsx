'use client';

import React, { useState } from 'react';

const categories = [
  { id: 'cat-all', label: 'All Events', emoji: '✨' },
  { id: 'cat-tech', label: 'Technology', emoji: '💻' },
  { id: 'cat-ai', label: 'AI & ML', emoji: '🤖' },
  { id: 'cat-music', label: 'Music', emoji: '🎵' },
  { id: 'cat-sports', label: 'Sports', emoji: '⚽' },
  { id: 'cat-design', label: 'Design', emoji: '🎨' },
  { id: 'cat-talks', label: 'Talks', emoji: '🗣️' },
  { id: 'cat-dance', label: 'Dance', emoji: '💃' },
  { id: 'cat-photo', label: 'Photography', emoji: '📸' },
  { id: 'cat-startup', label: 'Startup', emoji: '🚀' },
  { id: 'cat-debate', label: 'Debate', emoji: '🏛️' },
  { id: 'cat-gaming', label: 'Gaming', emoji: '🎮' },
  { id: 'cat-literature', label: 'Literature', emoji: '📚' },
  { id: 'cat-film', label: 'Film', emoji: '🎬' },
  { id: 'cat-wellness', label: 'Wellness', emoji: '🧘' },
  { id: 'cat-robotics', label: 'Robotics', emoji: '🦾' },
];

const sortOptions = [
  { id: 'sort-trending', label: 'Trending' },
  { id: 'sort-newest', label: 'Newest' },
  { id: 'sort-date', label: 'Date' },
  { id: 'sort-popular', label: 'Most Popular' },
  { id: 'sort-free', label: 'Free Only' },
];

export default function CategoryFilterBar() {
  const [activeCategory, setActiveCategory] = useState('cat-all');
  const [activeSort, setActiveSort] = useState('sort-trending');

  return (
    <div className="space-y-3">
      {/* Category Chips */}
      <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-1">
        {categories?.map((cat) => (
          <button
            key={cat?.id}
            onClick={() => setActiveCategory(cat?.id)}
            className={`flex-shrink-0 flex items-center gap-1.5 px-3 py-2 rounded-xl text-sm font-500 transition-all duration-150 ${
              activeCategory === cat?.id
                ? 'gradient-primary text-white shadow-violet-glow'
                : 'bg-muted text-muted-foreground hover:text-foreground hover:bg-muted/80 border border-border'
            }`}
          >
            <span>{cat?.emoji}</span>
            <span>{cat?.label}</span>
          </button>
        ))}
      </div>
      {/* Sort + Count */}
      <div className="flex items-center justify-between">
        <div className="flex gap-2 overflow-x-auto scrollbar-hide">
          {sortOptions?.map((opt) => (
            <button
              key={opt?.id}
              onClick={() => setActiveSort(opt?.id)}
              className={`flex-shrink-0 px-3 py-1.5 rounded-lg text-xs font-500 transition-all ${
                activeSort === opt?.id
                  ? 'bg-primary/10 text-primary border border-primary/20' :'text-muted-foreground hover:text-foreground'
              }`}
            >
              {opt?.label}
            </button>
          ))}
        </div>
        <span className="text-xs text-muted-foreground flex-shrink-0 ml-3">
          <span className="text-foreground font-600">24</span> events found
        </span>
      </div>
    </div>
  );
}