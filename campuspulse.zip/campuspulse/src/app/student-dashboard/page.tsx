import React from 'react';
import AppLayout from '@/components/AppLayout';
import DashboardHero from './components/DashboardHero';
import KPIBentoGrid from './components/KPIBentoGrid';
import RegisteredEventsList from './components/RegisteredEventsList';
import DashboardAIRecs from './components/DashboardAIRecs';
import WeeklySchedule from './components/WeeklySchedule';
import ActivityChart from './components/ActivityChart';
import NotificationFeed from './components/NotificationFeed';

export default function StudentDashboardPage() {
  return (
    <AppLayout activePath="/student-dashboard">
      <div className="space-y-6">
        {/* Hero */}
        <DashboardHero />

        {/* KPI Bento Grid */}
        <KPIBentoGrid />

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 xl:grid-cols-3 2xl:grid-cols-3 gap-6">
          {/* Left: 2/3 */}
          <div className="xl:col-span-2 space-y-6">
            <WeeklySchedule />
            <RegisteredEventsList />
            <ActivityChart />
          </div>

          {/* Right: 1/3 */}
          <div className="xl:col-span-1 space-y-6">
            <NotificationFeed />
            <DashboardAIRecs />
          </div>
        </div>
      </div>
    </AppLayout>
  );
}