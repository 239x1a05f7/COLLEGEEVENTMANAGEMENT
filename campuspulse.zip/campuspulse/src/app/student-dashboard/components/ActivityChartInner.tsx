'use client';

import React, { useState } from 'react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  Legend,
} from 'recharts';
import Icon from '@/components/ui/AppIcon';

const weeklyData = [
  { day: 'Mon', registrations: 1, attendance: 1, points: 120 },
  { day: 'Tue', registrations: 0, attendance: 0, points: 0 },
  { day: 'Wed', registrations: 2, attendance: 1, points: 180 },
  { day: 'Thu', registrations: 1, attendance: 1, points: 140 },
  { day: 'Fri', registrations: 3, attendance: 2, points: 260 },
  { day: 'Sat', registrations: 1, attendance: 1, points: 110 },
  { day: 'Sun', registrations: 0, attendance: 0, points: 0 },
];

const monthlyData = [
  { week: 'Apr W1', registrations: 2, attendance: 2, points: 240 },
  { week: 'Apr W2', registrations: 4, attendance: 3, points: 380 },
  { week: 'Apr W3', registrations: 1, attendance: 1, points: 120 },
  { week: 'Apr W4', registrations: 5, attendance: 4, points: 490 },
  { week: 'May W1', registrations: 3, attendance: 2, points: 310 },
  { week: 'May W2', registrations: 8, attendance: 0, points: 0 },
];

const categoryData = [
  { category: 'Tech', events: 4 },
  { category: 'Design', events: 2 },
  { category: 'Startup', events: 2 },
  { category: 'AI/ML', events: 3 },
  { category: 'Sports', events: 1 },
  { category: 'Music', events: 1 },
];

interface CustomTooltipProps {
  active?: boolean;
  payload?: Array<{ name: string; value: number; color: string }>;
  label?: string;
}

function CustomTooltip({ active, payload, label }: CustomTooltipProps) {
  if (!active || !payload || !payload.length) return null;
  return (
    <div className="glass-card rounded-xl px-3 py-2.5 shadow-glass border border-border">
      <p className="text-xs font-600 text-foreground mb-1.5">{label}</p>
      {payload.map((p) => (
        <div key={`tooltip-${p.name}`} className="flex items-center gap-2 text-xs">
          <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: p.color }} />
          <span className="text-muted-foreground capitalize">{p.name}:</span>
          <span className="text-foreground font-600 tabular-nums">{p.value}</span>
        </div>
      ))}
    </div>
  );
}

export default function ActivityChartInner() {
  const [chartView, setChartView] = useState<'weekly' | 'monthly' | 'categories'>('weekly');

  const data = chartView === 'weekly' ? weeklyData : chartView === 'monthly' ? monthlyData : categoryData;
  const xKey = chartView === 'weekly' ? 'day' : chartView === 'monthly' ? 'week' : 'category';

  return (
    <div className="glass-card rounded-2xl overflow-hidden">
      <div className="p-5 border-b border-border flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-base font-700 text-foreground">My Activity</h2>
          <p className="text-xs text-muted-foreground mt-0.5">Registrations, attendance & points earned</p>
        </div>
        <div className="flex gap-2">
          {([
            { key: 'weekly', label: 'This Week' },
            { key: 'monthly', label: 'This Month' },
            { key: 'categories', label: 'By Category' },
          ] as const).map((v) => (
            <button
              key={`chart-view-${v.key}`}
              onClick={() => setChartView(v.key)}
              className={`px-3 py-1.5 rounded-lg text-xs font-600 transition-all ${
                chartView === v.key
                  ? 'bg-primary/10 text-primary border border-primary/20' :'text-muted-foreground hover:text-foreground'
              }`}
            >
              {v.label}
            </button>
          ))}
        </div>
      </div>

      <div className="p-5">
        {/* Summary Row */}
        <div className="grid grid-cols-3 gap-4 mb-6">
          {[
            { label: 'Events Registered', value: '8', icon: 'CalendarIcon', color: 'text-primary' },
            { label: 'Events Attended', value: '7', icon: 'CheckCircleIcon', color: 'text-success' },
            { label: 'Points Earned', value: '1,240', icon: 'BoltIcon', color: 'text-accent' },
          ].map((s) => (
            <div key={`activity-summary-${s.label.replace(/\s/g, '-').toLowerCase()}`} className="bg-muted/50 rounded-xl p-3 text-center">
              <Icon name={s.icon as any} size={16} className={`${s.color} mx-auto mb-1`} />
              <p className="text-lg font-800 text-foreground tabular-nums">{s.value}</p>
              <p className="text-xs text-muted-foreground">{s.label}</p>
            </div>
          ))}
        </div>

        {/* Chart */}
        <div style={{ height: 220 }}>
          <ResponsiveContainer width="100%" height="100%">
            {chartView === 'categories' ? (
              <BarChart data={categoryData} barSize={28}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
                <XAxis dataKey="category" tick={{ fill: 'var(--muted-foreground)', fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: 'var(--muted-foreground)', fontSize: 11 }} axisLine={false} tickLine={false} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="events" fill="var(--primary)" radius={[6, 6, 0, 0]} name="Events" />
              </BarChart>
            ) : (
              <AreaChart data={data}>
                <defs>
                  <linearGradient id="gradReg" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="var(--primary)" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="var(--primary)" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="gradAtt" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="var(--success)" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="var(--success)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
                <XAxis dataKey={xKey} tick={{ fill: 'var(--muted-foreground)', fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: 'var(--muted-foreground)', fontSize: 11 }} axisLine={false} tickLine={false} />
                <Tooltip content={<CustomTooltip />} />
                <Legend
                  wrapperStyle={{ fontSize: '12px', color: 'var(--muted-foreground)' }}
                  iconType="circle"
                  iconSize={8}
                />
                <Area
                  type="monotone"
                  dataKey="registrations"
                  stroke="var(--primary)"
                  strokeWidth={2}
                  fill="url(#gradReg)"
                  name="Registrations"
                  dot={{ fill: 'var(--primary)', strokeWidth: 0, r: 3 }}
                />
                <Area
                  type="monotone"
                  dataKey="attendance"
                  stroke="var(--success)"
                  strokeWidth={2}
                  fill="url(#gradAtt)"
                  name="Attended"
                  dot={{ fill: 'var(--success)', strokeWidth: 0, r: 3 }}
                />
              </AreaChart>
            )}
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}