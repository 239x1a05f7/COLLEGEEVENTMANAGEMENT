'use client';

import React, { useState } from 'react';
import Icon from '@/components/ui/AppIcon';
import StatusBadge from '@/components/ui/StatusBadge';
import Modal from '@/components/ui/Modal';

const registeredEvents = [
  {
    id: 'reg-001',
    title: 'National Level Hackathon 2026',
    club: 'TechCraft Club',
    date: 'May 15–17, 2026',
    time: '9:00 AM',
    location: 'Computer Center, Block A',
    status: 'upcoming' as const,
    registrationId: 'REG-TC-2026-0842',
    qrData: 'REG-TC-2026-0842|arjun.reddy@vnit.ac.in|hackathon2026',
    checkedIn: false,
    category: 'Technology',
    isFree: true,
  },
  {
    id: 'reg-002',
    title: 'UI/UX Design Bootcamp',
    club: 'Design Collective',
    date: 'May 14, 2026',
    time: '2:00 PM',
    location: 'Innovation Lab, Block B',
    status: 'upcoming' as const,
    registrationId: 'REG-DC-2026-0317',
    qrData: 'REG-DC-2026-0317|arjun.reddy@vnit.ac.in|designbootcamp',
    checkedIn: false,
    category: 'Design',
    isFree: true,
  },
  {
    id: 'reg-003',
    title: 'Startup Weekend VNIT 2026',
    club: 'E-Cell VNIT',
    date: 'May 16–18, 2026',
    time: '9:00 AM',
    location: 'Seminar Complex',
    status: 'upcoming' as const,
    registrationId: 'REG-EC-2026-1104',
    qrData: 'REG-EC-2026-1104|arjun.reddy@vnit.ac.in|startupweekend',
    checkedIn: false,
    category: 'Entrepreneurship',
    isFree: false,
    price: 299,
  },
  {
    id: 'reg-004',
    title: 'AI Research Paper Reading Club — May Edition',
    club: 'AI Research Society',
    date: 'May 8, 2026',
    time: '5:00 PM',
    location: 'Seminar Room 3',
    status: 'live' as const,
    registrationId: 'REG-AI-2026-0059',
    qrData: 'REG-AI-2026-0059|arjun.reddy@vnit.ac.in|aipaperclub',
    checkedIn: true,
    category: 'AI & ML',
    isFree: true,
  },
  {
    id: 'reg-005',
    title: 'Open Source Sprint — Build for Bharat',
    club: 'OSS Circle',
    date: 'May 12, 2026',
    time: '10:00 AM',
    location: 'Innovation Lab',
    status: 'upcoming' as const,
    registrationId: 'REG-OS-2026-0228',
    qrData: 'REG-OS-2026-0228|arjun.reddy@vnit.ac.in|ossprint',
    checkedIn: false,
    category: 'Technology',
    isFree: true,
  },
];

export default function RegisteredEventsList() {
  const [qrModal, setQrModal] = useState<{ open: boolean; event: typeof registeredEvents[0] | null }>({ open: false, event: null });
  const [filter, setFilter] = useState<'all' | 'upcoming' | 'live' | 'completed'>('all');

  const filtered = registeredEvents.filter((e) => filter === 'all' || e.status === filter);

  return (
    <>
      <div className="glass-card rounded-2xl overflow-hidden">
        <div className="p-5 border-b border-border flex items-center justify-between flex-wrap gap-3">
          <div>
            <h2 className="text-base font-700 text-foreground">My Registrations</h2>
            <p className="text-xs text-muted-foreground mt-0.5">{registeredEvents.length} events registered this semester</p>
          </div>
          <div className="flex gap-2">
            {(['all', 'upcoming', 'live'] as const).map((f) => (
              <button
                key={`filter-reg-${f}`}
                onClick={() => setFilter(f)}
                className={`px-3 py-1.5 rounded-lg text-xs font-600 transition-all ${
                  filter === f
                    ? 'bg-primary/10 text-primary border border-primary/20' :'text-muted-foreground hover:text-foreground'
                }`}
              >
                {f === 'all' ? 'All' : f === 'live' ? 'Live Now' : 'Upcoming'}
                {f === 'live' && <span className="ml-1 w-1.5 h-1.5 rounded-full bg-success inline-block" />}
              </button>
            ))}
          </div>
        </div>

        <div className="divide-y divide-border">
          {filtered.length === 0 ? (
            <div className="text-center py-12">
              <Icon name="CalendarDaysIcon" size={36} className="text-muted-foreground mx-auto mb-3" />
              <p className="text-sm font-600 text-foreground">No registered events</p>
              <p className="text-xs text-muted-foreground mt-1 max-w-xs mx-auto">
                Explore campus events and register to see them here
              </p>
              <button className="mt-4 btn-primary text-xs font-600 px-4 py-2 rounded-xl">Browse Events</button>
            </div>
          ) : (
            filtered.map((event) => (
              <div key={event.id} className="flex items-center gap-4 p-4 hover:bg-muted/20 transition-colors group">
                {/* Status Indicator */}
                <div className="flex-shrink-0">
                  {event.status === 'live' ? (
                    <div className="w-10 h-10 rounded-xl bg-success/10 border border-success/20 flex items-center justify-center">
                      <span className="w-3 h-3 rounded-full bg-success live-pulse" />
                    </div>
                  ) : event.checkedIn ? (
                    <div className="w-10 h-10 rounded-xl bg-success/10 border border-success/20 flex items-center justify-center">
                      <Icon name="CheckCircleIcon" size={18} className="text-success" />
                    </div>
                  ) : (
                    <div className="w-10 h-10 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center">
                      <Icon name="CalendarIcon" size={18} className="text-primary" />
                    </div>
                  )}
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="text-sm font-600 text-foreground truncate group-hover:text-primary transition-colors">
                      {event.title}
                    </h3>
                    <StatusBadge variant={event.status} pulse={event.status === 'live'} />
                    {event.checkedIn && (
                      <span className="text-xs text-success font-600 flex items-center gap-1">
                        <Icon name="CheckIcon" size={11} />
                        Checked In
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground flex-wrap">
                    <span>{event.club}</span>
                    <span className="flex items-center gap-1">
                      <Icon name="CalendarIcon" size={11} />
                      {event.date} · {event.time}
                    </span>
                    <span className="flex items-center gap-1">
                      <Icon name="MapPinIcon" size={11} />
                      {event.location}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-0.5 font-mono">{event.registrationId}</p>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-2 flex-shrink-0">
                  <button
                    onClick={() => setQrModal({ open: true, event })}
                    className="flex items-center gap-1.5 bg-primary/10 text-primary border border-primary/20 hover:bg-primary/20 px-3 py-2 rounded-xl text-xs font-600 transition-all"
                  >
                    <Icon name="QrCodeIcon" size={14} />
                    <span className="hidden sm:block">QR Code</span>
                  </button>
                  <button className="p-2 rounded-xl text-muted-foreground hover:text-foreground hover:bg-muted transition-all" aria-label="More options">
                    <Icon name="EllipsisVerticalIcon" size={16} />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* QR Code Modal */}
      <Modal
        isOpen={qrModal.open}
        onClose={() => setQrModal({ open: false, event: null })}
        title="Event Entry QR Code"
        size="sm"
      >
        {qrModal.event && <QRCodeDisplay event={qrModal.event} />}
      </Modal>
    </>
  );
}

function QRCodeDisplay({ event }: { event: typeof registeredEvents[0] }) {
  return (
    <div className="text-center space-y-4">
      <div className="bg-white p-4 rounded-2xl inline-block">
        {/* QR code placeholder — in production use qrcode.react */}
        <div className="w-48 h-48 bg-white flex items-center justify-center relative">
          <div className="grid grid-cols-7 gap-0.5 w-full h-full p-2">
            {Array.from({ length: 49 }).map((_, i) => {
              const isCorner = [0,1,2,3,4,5,6,7,13,14,20,21,27,28,34,35,41,42,43,44,45,46,47,48].includes(i);
              const isRandom = Math.sin(i * 7.3 + 13.7) > 0.1;
              return (
                <div
                  key={`qr-cell-${i + 1}`}
                  className={`rounded-sm ${isCorner || isRandom ? 'bg-zinc-900' : 'bg-white'}`}
                />
              );
            })}
          </div>
        </div>
      </div>

      <div>
        <p className="text-xs font-600 text-muted-foreground uppercase tracking-wider mb-1">Registration ID</p>
        <p className="text-sm font-700 text-foreground font-mono">{event.registrationId}</p>
      </div>

      <div className="glass-card rounded-xl p-3 text-left space-y-2">
        <div className="flex items-center gap-2">
          <Icon name="CalendarIcon" size={14} className="text-primary flex-shrink-0" />
          <div>
            <p className="text-xs font-600 text-foreground">{event.title}</p>
            <p className="text-xs text-muted-foreground">{event.date} · {event.time}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Icon name="MapPinIcon" size={14} className="text-muted-foreground flex-shrink-0" />
          <p className="text-xs text-muted-foreground">{event.location}</p>
        </div>
      </div>

      <p className="text-xs text-muted-foreground">
        Show this QR code at the entry gate for check-in. Valid for registered student only.
      </p>

      <button className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-muted text-foreground text-sm font-600 hover:bg-muted/80 transition-all border border-border">
        <Icon name="ArrowDownTrayIcon" size={14} />
        Download QR Code
      </button>
    </div>
  );
}