'use client';

import React from 'react';
import AppImage from '@/components/ui/AppImage';
import Icon from '@/components/ui/AppIcon';
import { toast } from 'sonner';

const recs = [
{
  id: 'dash-rec-1',
  title: 'Machine Learning Paper Reading Club',
  club: 'AI Research Society',
  date: 'May 11 · 5:00 PM',
  matchScore: 94,
  reason: 'AI/ML interest + 3 friends attending',
  banner: "https://img.rocket.new/generatedImages/rocket_gen_img_1b9b78950-1774149821493.png",
  bannerAlt: 'Glowing neural network visualization showing connected nodes on dark background',
  seatsLeft: 15,
  isFree: true
},
{
  id: 'dash-rec-2',
  title: 'Robotics Workshop — ROS2 & Autonomous Navigation',
  club: 'Robotics Society',
  date: 'May 8 · 4:00 PM',
  matchScore: 89,
  reason: 'Trending in CS department',
  banner: "https://images.unsplash.com/photo-1712238107648-4e94c158ab3d",
  bannerAlt: 'White robot arm performing precise movements in a laboratory setting',
  seatsLeft: 7,
  isFree: true
},
{
  id: 'dash-rec-3',
  title: 'Campus Finance & Investment Workshop',
  club: 'Finance Club',
  date: 'May 10 · 3:00 PM',
  matchScore: 76,
  reason: 'Popular with students in your year',
  banner: "https://img.rocket.new/generatedImages/rocket_gen_img_16ff49ed9-1769221457730.png",
  bannerAlt: 'Financial charts and graphs displayed on multiple screens in a trading room',
  seatsLeft: 31,
  isFree: true
}];


export default function DashboardAIRecs() {
  const handleRegister = (id: string, title: string) => {
    // BACKEND: POST /api/events/{id}/register
    toast.success(`Registered for ${title}!`);
  };

  return (
    <div className="glass-card rounded-2xl overflow-hidden">
      <div className="p-4 border-b border-border flex items-center gap-2">
        <div className="w-6 h-6 rounded-lg gradient-primary flex items-center justify-center">
          <Icon name="SparklesIcon" size={12} className="text-white" />
        </div>
        <div>
          <h2 className="text-sm font-700 text-foreground">AI Recommendations</h2>
          <p className="text-xs text-muted-foreground">Based on your activity</p>
        </div>
      </div>

      <div className="divide-y divide-border">
        {recs.map((rec) =>
        <div key={rec.id} className="p-4 hover:bg-muted/20 transition-colors group">
            <div className="flex gap-3">
              {/* Thumbnail */}
              <div className="relative w-16 h-16 rounded-xl overflow-hidden flex-shrink-0">
                <AppImage
                src={rec.banner}
                alt={rec.bannerAlt}
                fill
                className="object-cover group-hover:scale-105 transition-transform duration-300"
                sizes="64px" />
              
              </div>

              {/* Content */}
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-1 mb-1">
                  <h3 className="text-xs font-700 text-foreground leading-snug line-clamp-2 group-hover:text-primary transition-colors">
                    {rec.title}
                  </h3>
                  <span className="flex-shrink-0 flex items-center gap-0.5 bg-primary/10 text-primary text-xs font-700 px-1.5 py-0.5 rounded-full border border-primary/20">
                    <Icon name="SparklesIcon" size={9} />
                    {rec.matchScore}%
                  </span>
                </div>
                <p className="text-xs text-muted-foreground">{rec.club}</p>
                <p className="text-xs text-muted-foreground">{rec.date}</p>

                {/* AI Reason */}
                <p className="text-xs text-primary/80 mt-1 flex items-center gap-1">
                  <Icon name="LightBulbIcon" size={10} />
                  {rec.reason}
                </p>

                <div className="flex items-center justify-between mt-2">
                  <span className={`text-xs font-600 ${rec.seatsLeft <= 10 ? 'text-warning' : 'text-muted-foreground'}`}>
                    {rec.seatsLeft} seats left
                  </span>
                  <button
                  onClick={() => handleRegister(rec.id, rec.title)}
                  className="text-xs text-primary font-600 hover:underline flex items-center gap-0.5">
                  
                    Register
                    <Icon name="ArrowRightIcon" size={10} />
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="p-4 border-t border-border">
        <button className="w-full text-xs text-primary font-600 hover:underline flex items-center justify-center gap-1">
          View all AI recommendations
          <Icon name="ArrowRightIcon" size={12} />
        </button>
      </div>
    </div>);

}