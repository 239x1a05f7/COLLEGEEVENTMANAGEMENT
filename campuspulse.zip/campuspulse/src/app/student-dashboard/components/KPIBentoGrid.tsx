import React from 'react';
import Icon from '@/components/ui/AppIcon';

const kpiData = [
  {
    id: 'kpi-registered',
    label: 'Registered Events',
    value: '8',
    suffix: 'this semester',
    icon: 'CalendarDaysIcon',
    trend: '+3 this month',
    trendPositive: true,
    cardClass: 'gradient-card-violet',
    iconClass: 'text-primary',
    span: 'col-span-1',
  },
  {
    id: 'kpi-attendance',
    label: 'Attendance Rate',
    value: '87%',
    suffix: '7 of 8 attended',
    icon: 'CheckCircleIcon',
    trend: '+12% vs last month',
    trendPositive: true,
    cardClass: 'gradient-card-green',
    iconClass: 'text-success',
    span: 'col-span-1',
  },
  {
    id: 'kpi-engagement',
    label: 'Engagement Score',
    value: '1,240',
    suffix: 'Pulse Points',
    icon: 'BoltIcon',
    trend: 'Top 10% on campus',
    trendPositive: true,
    cardClass: 'gradient-card-cyan',
    iconClass: 'text-accent',
    span: 'col-span-1',
  },
  {
    id: 'kpi-clubs',
    label: 'Clubs Following',
    value: '6',
    suffix: 'of 38 active clubs',
    icon: 'UserGroupIcon',
    trend: '+2 this week',
    trendPositive: true,
    cardClass: 'gradient-card-amber',
    iconClass: 'text-warning',
    span: 'col-span-1',
  },
  {
    id: 'kpi-saved',
    label: 'Saved Events',
    value: '14',
    suffix: '3 happening soon',
    icon: 'BookmarkIcon',
    trend: '2 closing soon',
    trendPositive: false,
    cardClass: 'gradient-card-red',
    iconClass: 'text-danger',
    span: 'col-span-1',
  },
];

export default function KPIBentoGrid() {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-5 2xl:grid-cols-5 gap-4">
      {kpiData.map((kpi) => (
        <div
          key={kpi.id}
          className={`${kpi.cardClass} rounded-2xl p-5 card-hover cursor-pointer`}
        >
          <div className="flex items-start justify-between mb-4">
            <p className="text-xs font-500 text-muted-foreground uppercase tracking-wider leading-tight">
              {kpi.label}
            </p>
            <div className="w-9 h-9 rounded-xl bg-muted/50 flex items-center justify-center flex-shrink-0">
              <Icon name={kpi.icon as any} size={16} className={kpi.iconClass} />
            </div>
          </div>
          <p className="text-3xl font-800 text-foreground tabular-nums mb-1">{kpi.value}</p>
          <p className="text-xs text-muted-foreground mb-3">{kpi.suffix}</p>
          <div className={`flex items-center gap-1 text-xs font-600 ${kpi.trendPositive ? 'text-success' : 'text-warning'}`}>
            <Icon name={kpi.trendPositive ? 'ArrowTrendingUpIcon' : 'ExclamationTriangleIcon'} size={12} />
            <span>{kpi.trend}</span>
          </div>
        </div>
      ))}
    </div>
  );
}