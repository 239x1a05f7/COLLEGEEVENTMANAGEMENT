import React from 'react';
import Icon from '@/components/ui/AppIcon';

export default function DashboardHero() {
  return (
    <div className="relative overflow-hidden rounded-3xl gradient-card-violet p-6 md:p-8">
      {/* Background glow */}
      <div className="absolute -top-10 -right-10 w-48 h-48 rounded-full opacity-20 blur-3xl"
        style={{ background: 'radial-gradient(circle, #7C3AED, transparent)' }} />

      <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        {/* Left: User Info */}
        <div className="flex items-center gap-4">
          <div className="relative">
            <div className="w-16 h-16 rounded-2xl gradient-primary flex items-center justify-center text-white text-xl font-800">
              AR
            </div>
            <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-success border-2 border-background flex items-center justify-center">
              <span className="w-2 h-2 rounded-full bg-success live-pulse" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <h1 className="text-xl font-800 text-foreground">Good evening, Arjun!</h1>
              <span className="text-xl">👋</span>
            </div>
            <p className="text-sm text-muted-foreground">Computer Science · 3rd Year · VNIT Nagpur</p>
            <div className="flex items-center gap-3 mt-2">
              <div className="flex items-center gap-1.5 bg-primary/10 border border-primary/20 rounded-full px-3 py-1">
                <Icon name="TrophyIcon" size={12} className="text-primary" />
                <span className="text-xs font-600 text-primary">Rank #23 on Campus</span>
              </div>
              <div className="flex items-center gap-1.5 bg-warning/10 border border-warning/20 rounded-full px-3 py-1">
                <Icon name="FireIcon" size={12} className="text-warning" />
                <span className="text-xs font-600 text-warning">12-day streak</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right: Quick Actions */}
        <div className="flex items-center gap-3">
          <div className="text-center hidden sm:block">
            <p className="text-2xl font-800 text-foreground tabular-nums">3</p>
            <p className="text-xs text-muted-foreground">Events today</p>
          </div>
          <div className="w-px h-10 bg-border hidden sm:block" />
          <div className="text-center hidden sm:block">
            <p className="text-2xl font-800 text-foreground tabular-nums">1,240</p>
            <p className="text-xs text-muted-foreground">Pulse Points</p>
          </div>
          <div className="flex gap-2 ml-2">
            <button className="flex items-center gap-2 bg-primary text-white px-4 py-2.5 rounded-xl text-sm font-600 hover:bg-primary/90 transition-all active:scale-95">
              <Icon name="MagnifyingGlassIcon" size={14} />
              Discover
            </button>
            <button className="flex items-center gap-2 bg-muted text-muted-foreground hover:text-foreground px-4 py-2.5 rounded-xl text-sm font-600 transition-all border border-border">
              <Icon name="QrCodeIcon" size={14} />
              My QR
            </button>
          </div>
        </div>
      </div>

      {/* Next Event Banner */}
      <div className="relative z-10 mt-5 flex items-center gap-3 bg-black/20 backdrop-blur-sm rounded-2xl px-4 py-3 border border-white/10">
        <div className="w-2 h-2 rounded-full bg-success live-pulse flex-shrink-0" />
        <div className="flex-1 min-w-0">
          <p className="text-xs text-muted-foreground">Your next event</p>
          <p className="text-sm font-600 text-foreground">AI/ML Hackathon 2026 — Check-in opens in</p>
        </div>
        <div className="flex items-center gap-1 text-accent font-700 text-sm flex-shrink-0">
          <Icon name="ClockIcon" size={14} />
          <span className="tabular-nums">2h 14m</span>
        </div>
      </div>
    </div>
  );
}