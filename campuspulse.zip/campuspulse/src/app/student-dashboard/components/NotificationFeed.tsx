'use client';

import React, { useState } from 'react';
import Icon from '@/components/ui/AppIcon';

const notifications = [
  {
    id: 'notif-001',
    type: 'urgent',
    icon: 'ExclamationTriangleIcon',
    iconBg: 'bg-danger/10',
    iconColor: 'text-danger',
    title: 'Registration closing soon!',
    message: 'TEDx VNIT 2026 — only 13 spots left. You saved this event.',
    time: '5m ago',
    unread: true,
    action: 'Register Now',
  },
  {
    id: 'notif-002',
    type: 'live',
    icon: 'BoltIcon',
    iconBg: 'bg-success/10',
    iconColor: 'text-success',
    title: 'Event is live now!',
    message: 'AI Research Paper Club just started at Seminar Room 3. You\'re registered.',
    time: '12m ago',
    unread: true,
    action: 'Check In',
  },
  {
    id: 'notif-003',
    type: 'announcement',
    icon: 'MegaphoneIcon',
    iconBg: 'bg-primary/10',
    iconColor: 'text-primary',
    title: 'TechCraft Club announcement',
    message: 'Hackathon team formation portal is now open. Find teammates before May 12.',
    time: '1h ago',
    unread: true,
    action: null,
  },
  {
    id: 'notif-004',
    type: 'recommendation',
    icon: 'SparklesIcon',
    iconBg: 'bg-accent/10',
    iconColor: 'text-accent',
    title: 'AI picked this for you',
    message: 'Robotics Workshop (ROS2) matches your tech interests — 7 spots left.',
    time: '2h ago',
    unread: false,
    action: 'View Event',
  },
  {
    id: 'notif-005',
    type: 'achievement',
    icon: 'TrophyIcon',
    iconBg: 'bg-warning/10',
    iconColor: 'text-warning',
    title: 'New badge earned!',
    message: 'You earned the "Tech Enthusiast" badge for attending 3 tech events this month.',
    time: '3h ago',
    unread: false,
    action: null,
  },
  {
    id: 'notif-006',
    type: 'reminder',
    icon: 'ClockIcon',
    iconBg: 'bg-muted',
    iconColor: 'text-muted-foreground',
    title: 'Event reminder',
    message: 'UI/UX Design Bootcamp starts in 6 days. Make sure you\'re prepared.',
    time: '1d ago',
    unread: false,
    action: null,
  },
];

export default function NotificationFeed() {
  const [items, setItems] = useState(notifications);
  const unreadCount = items.filter((n) => n.unread).length;

  const markAllRead = () => {
    setItems((prev) => prev.map((n) => ({ ...n, unread: false })));
  };

  const dismiss = (id: string) => {
    setItems((prev) => prev.filter((n) => n.id !== id));
  };

  return (
    <div className="glass-card rounded-2xl overflow-hidden">
      <div className="p-4 border-b border-border flex items-center justify-between">
        <div className="flex items-center gap-2">
          <h2 className="text-sm font-700 text-foreground">Notifications</h2>
          {unreadCount > 0 && (
            <span className="bg-primary text-white text-xs rounded-full px-2 py-0.5 font-700 tabular-nums">
              {unreadCount}
            </span>
          )}
        </div>
        {unreadCount > 0 && (
          <button onClick={markAllRead} className="text-xs text-primary font-600 hover:underline">
            Mark all read
          </button>
        )}
      </div>

      <div className="divide-y divide-border max-h-[480px] overflow-y-auto scrollbar-hide">
        {items.length === 0 ? (
          <div className="text-center py-10">
            <Icon name="BellSlashIcon" size={28} className="text-muted-foreground mx-auto mb-2" />
            <p className="text-sm font-600 text-foreground">All caught up!</p>
            <p className="text-xs text-muted-foreground mt-1">No new notifications</p>
          </div>
        ) : (
          items.map((notif) => (
            <div
              key={notif.id}
              className={`p-4 hover:bg-muted/20 transition-colors group relative ${notif.unread ? 'bg-primary/3' : ''}`}
            >
              {notif.unread && (
                <span className="absolute left-2 top-1/2 -translate-y-1/2 w-1.5 h-1.5 rounded-full bg-primary" />
              )}
              <div className="flex items-start gap-3 pl-2">
                <div className={`w-8 h-8 rounded-xl ${notif.iconBg} flex items-center justify-center flex-shrink-0`}>
                  <Icon name={notif.icon as any} size={14} className={notif.iconColor} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-1">
                    <p className="text-xs font-700 text-foreground leading-snug">{notif.title}</p>
                    <button
                      onClick={() => dismiss(notif.id)}
                      className="opacity-0 group-hover:opacity-100 transition-opacity p-0.5 text-muted-foreground hover:text-foreground flex-shrink-0"
                      aria-label="Dismiss notification"
                    >
                      <Icon name="XMarkIcon" size={12} />
                    </button>
                  </div>
                  <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">{notif.message}</p>
                  <div className="flex items-center justify-between mt-2">
                    <span className="text-xs text-muted-foreground">{notif.time}</span>
                    {notif.action && (
                      <button className="text-xs text-primary font-600 hover:underline">
                        {notif.action} →
                      </button>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}