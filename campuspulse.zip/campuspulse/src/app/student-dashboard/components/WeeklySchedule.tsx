'use client';

import React, { useState } from 'react';
import Icon from '@/components/ui/AppIcon';

const weekDays = [
  { id: 'day-thu', day: 'Thu', date: 'May 8', isToday: true },
  { id: 'day-fri', day: 'Fri', date: 'May 9', isToday: false },
  { id: 'day-sat', day: 'Sat', date: 'May 10', isToday: false },
  { id: 'day-sun', day: 'Sun', date: 'May 11', isToday: false },
  { id: 'day-mon', day: 'Mon', date: 'May 12', isToday: false },
  { id: 'day-tue', day: 'Tue', date: 'May 13', isToday: false },
  { id: 'day-wed', day: 'Wed', date: 'May 14', isToday: false },
];

const scheduleEvents: Record<string, Array<{ id: string; title: string; time: string; club: string; location: string; color: string; type: 'registered' | 'saved' | 'recommended' }>> = {
  'May 8': [
    { id: 'sch-1', title: 'AI/ML Hackathon — Day 1', time: '9:00 AM', club: 'TechCraft Club', location: 'Computer Center', color: 'bg-primary', type: 'registered' },
    { id: 'sch-2', title: 'Sargam Music Night', time: '7:00 PM', club: 'Sargam Club', location: 'Open Air Theatre', color: 'bg-warning', type: 'saved' },
  ],
  'May 9': [
    { id: 'sch-3', title: 'AI/ML Hackathon — Day 2', time: '9:00 AM', club: 'TechCraft Club', location: 'Computer Center', color: 'bg-primary', type: 'registered' },
  ],
  'May 10': [
    { id: 'sch-4', title: 'Photography Walk', time: '6:00 AM', club: 'Lens & Light', location: 'Main Gate', color: 'bg-danger', type: 'saved' },
    { id: 'sch-5', title: 'Short Film Screening', time: '7:00 PM', club: 'Cine Society', location: 'Open Air Theatre', color: 'bg-accent', type: 'recommended' },
  ],
  'May 11': [],
  'May 12': [
    { id: 'sch-6', title: 'Open Source Sprint', time: '10:00 AM', club: 'OSS Circle', location: 'Innovation Lab', color: 'bg-success', type: 'recommended' },
  ],
  'May 13': [],
  'May 14': [
    { id: 'sch-7', title: 'UI/UX Design Bootcamp', time: '2:00 PM', club: 'Design Collective', location: 'Innovation Lab', color: 'bg-warning', type: 'registered' },
  ],
};

export default function WeeklySchedule() {
  const [selectedDate, setSelectedDate] = useState('May 8');

  const dayEvents = scheduleEvents[selectedDate] || [];

  const typeConfig = {
    registered: { label: 'Registered', color: 'text-primary bg-primary/10 border-primary/20' },
    saved: { label: 'Saved', color: 'text-warning bg-warning/10 border-warning/20' },
    recommended: { label: 'AI Pick', color: 'text-accent bg-accent/10 border-accent/20' },
  };

  return (
    <div className="glass-card rounded-2xl overflow-hidden">
      <div className="p-5 border-b border-border flex items-center justify-between">
        <div>
          <h2 className="text-base font-700 text-foreground">My Schedule</h2>
          <p className="text-xs text-muted-foreground mt-0.5">May 8–14, 2026</p>
        </div>
        <button className="text-xs text-primary font-600 hover:underline flex items-center gap-1">
          <Icon name="CalendarIcon" size={12} />
          Add to Calendar
        </button>
      </div>

      {/* Day Selector */}
      <div className="flex gap-2 p-4 overflow-x-auto scrollbar-hide border-b border-border">
        {weekDays.map((d) => {
          const hasEvents = (scheduleEvents[d.date] || []).length > 0;
          return (
            <button
              key={d.id}
              onClick={() => setSelectedDate(d.date)}
              className={`flex-shrink-0 flex flex-col items-center gap-1 px-3 py-2.5 rounded-xl transition-all ${
                selectedDate === d.date
                  ? 'gradient-primary text-white'
                  : d.isToday
                  ? 'bg-primary/10 text-primary border border-primary/20' :'bg-muted text-muted-foreground hover:text-foreground'
              }`}
            >
              <span className="text-xs font-500">{d.day}</span>
              <span className="text-sm font-700">{d.date.split(' ')[1]}</span>
              {hasEvents && (
                <span className={`w-1.5 h-1.5 rounded-full ${selectedDate === d.date ? 'bg-white/70' : 'bg-primary'}`} />
              )}
            </button>
          );
        })}
      </div>

      {/* Events for Selected Day */}
      <div className="p-4">
        {dayEvents.length === 0 ? (
          <div className="text-center py-8">
            <Icon name="CalendarDaysIcon" size={32} className="text-muted-foreground mx-auto mb-2" />
            <p className="text-sm font-600 text-foreground">No events scheduled</p>
            <p className="text-xs text-muted-foreground mt-1">Explore and register for events on this day</p>
            <button className="mt-3 text-xs text-primary font-600 hover:underline">Browse events →</button>
          </div>
        ) : (
          <div className="space-y-3">
            {dayEvents.map((event) => (
              <div key={event.id} className="flex items-start gap-3 p-3 bg-muted/30 rounded-xl hover:bg-muted/50 transition-colors cursor-pointer group">
                <div className={`w-1 self-stretch rounded-full flex-shrink-0 ${event.color}`} />
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <h3 className="text-sm font-600 text-foreground group-hover:text-primary transition-colors leading-snug">{event.title}</h3>
                    <span className={`flex-shrink-0 text-xs font-600 px-2 py-0.5 rounded-full border ${typeConfig[event.type].color}`}>
                      {typeConfig[event.type].label}
                    </span>
                  </div>
                  <div className="flex items-center gap-3 mt-1.5 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Icon name="ClockIcon" size={11} />
                      {event.time}
                    </span>
                    <span className="flex items-center gap-1">
                      <Icon name="MapPinIcon" size={11} />
                      {event.location}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-0.5">{event.club}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}